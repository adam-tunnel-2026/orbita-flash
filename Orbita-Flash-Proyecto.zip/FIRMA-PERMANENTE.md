# Órbita Flash 0.9.0 — firma permanente

## Estado y límite de la migración

Se ha creado una identidad nueva de firma, conservada en un archivo privado.
No es la firma de las APK antiguas: 0.7.1 y 0.8.1 tenían certificados distintos.
Esta identidad nueva NO permite actualizar encima de esas APK antiguas.
No se ha recuperado la clave antigua. No se borra ni migra el teléfono del usuario.

No desinstales todavía una versión antigua con monedas o marcas importantes.
Antes de solicitar una reinstalación a usuarios hay que probar la serie nueva y
planificar la conservación de sus datos. La prueba automatizada no recupera los
datos de una instalación con una firma distinta.

La distribución nueva compila siempre RELEASE con la misma clave. Incluso las
APK DEBUG de prueba usan esa identidad. Si falta el secreto o no coincide la
huella fijada, la compilación se detiene: nunca se crea otra clave automáticamente.

## Configuración inicial: solo una vez

1. Guardar una copia segura del archivo `Orbita-Flash-Firma-PRIVADA.txt`.
   NO subirlo al repositorio, no compartirlo y no pegarlo en un chat. Contiene
   la clave cifrada y los datos necesarios para utilizarla. Conservar otra copia
   segura fuera del móvil; no regenerarla para cada actualización.
2. En GitHub, abrir el repositorio `adam-tunnel-2026/orbita-flash` → Settings →
   Secrets and variables → Actions → New repository secret.
3. Nombre exacto: `ORBITA_SIGNING_BUNDLE`.
   Valor: copiar TODO el contenido del archivo privado, sin cambiarlo, sin
   añadir comillas, comentarios ni bloques Markdown. Pulsar Add secret.
   El archivo tiene menos de 48 KB. No se necesita ningún otro secreto de firma.
4. Sustituir `.github/workflows/orbita-flash.yml` por el workflow nuevo entregado.
   Debe quedar UN ÚNICO workflow de Órbita Flash. No guardarlo en la raíz.
5. Sustituir `Orbita-Flash-Proyecto.zip` de la raíz por el nuevo, sin descomprimirlo.
   Subir solo este ZIP y mantener el workflow anterior NO configura la firma:
   el workflow anterior se detendrá intencionadamente antes de crear otra APK DEBUG.

No requiere modificar DigitalOcean, Cloudflare, el dominio, Adam Tunnel ni Encajoy.
El proyecto público contiene únicamente la huella del certificado público, no la
clave privada ni contraseñas. Las claves temporales del runner no se publican como
artefactos ni se guardan en la caché de Gradle.

## Compilación y primera prueba

Un push genera el artefacto `Orbita-Flash-APK-FIRMADA`, cuyo ZIP contiene
únicamente `Orbita-Flash.apk`. Los metadatos y la huella se conservan en el
proceso de publicación, fuera de ese ZIP de descarga. No publica automáticamente
una Release ni envía una actualización.

Para ejecutar la prueba automática inicial:

- Actions → Orbita Flash - firma permanente → Run workflow.
- `verify_update`: activado.
- `publish`: desactivado.

Se compila la APK RELEASE y, para el emulador limpio, dos APK DEBUG consecutivas
con códigos distintos y la misma identidad. Se comprueba la firma de las tres.
La prueba abre la primera, guarda un archivo de control en sus datos privados,
instala la segunda con `adb install -r`, comprueba que conserva el UID y el archivo,
y vuelve a abrir el juego para detectar un cierre inmediato.

Esto prueba la sustitución Android entre versiones de la NUEVA firma. No comprueba
la migración desde las claves antiguas, ni el diálogo visual de descarga, ni todos
los datos del WebView en Android. Las pruebas de monedero y conservación de claves
siguen siendo de cliente simulado. Antes de distribuir deben revisarse también
monedas, aspectos y pueblo en dos APK con la misma firma en un dispositivo real.

El emulador puede tardar varios minutos. Si falla, no se publica la versión.
Esta prueba todavía NO se ha ejecutado en esta sesión.

## Publicar actualizaciones cuando las pruebas estén superadas

Run workflow con `verify_update=true` y `publish=true`.
Se exige un repositorio público para la descarga sin credenciales del actualizador.
El workflow no cambia automáticamente la visibilidad del repositorio.
Crea una Release borrador con APK, metadatos y huella y la publica completa.
No reemplaza una versión ya publicada. La primera serie estable es 0.9.0, código 13.

Para las siguientes versiones, aumentar versionCode y versionName. Conservar el
mismo archivo privado, el mismo secreto y `signing-certificate.sha256`.
No cambiar la identidad por una supuesta solución de instalación.

Los usuarios que ya tengan instalada una APK de esta nueva serie con su firma
podrán instalar las siguientes encima, sin desinstalar. Android puede pedir
confirmar la instalación y autorizar la fuente. Los avisos con la app cerrada
siguen siendo periódicos; no se promete entrega instantánea.

## Validación realizada aquí

- Creación de la identidad nueva y comprobación de su certificado.
- Dos recuperaciones desde el mismo archivo privado producen exactamente la misma
  clave; se rechazan secreto ausente y certificado distinto.
- Proyecto público revisado para que no incluya clave ni contraseñas.
- Pruebas del juego, competición, idiomas y permisos correctas.
- Sintaxis del workflow y scripts comprobada.
- No se ha compilado Android ni ejecutado el emulador ni publicado en GitHub aquí:
  esta sesión no tiene acceso operativo al repositorio ni el SDK Android.

La huella pública fijada se encuentra en `signing-certificate.sha256`.
No se puede reconstruir la clave privada a partir de esa huella ni de una APK.
