package es.orbitaflash.game;

import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;

public class UpdateRulesTest {
 static int checks;
 static void check(boolean value){checks++;if(!value)throw new AssertionError("Check "+checks);}
 static void rejects(Runnable r){checks++;try{r.run();}catch(IllegalArgumentException expected){return;}throw new AssertionError("Expected invalid input "+checks);}
 public static void main(String[] args)throws Exception {
  String url="https://github.com/adam-tunnel-2026/orbita-flash/releases/download/v0.8.0/Orbita-Flash.apk";
  String hash="0".repeat(64);
  UpdateRules.Info info=new UpdateRules.Info(10,"0.8.0",url,hash,1024,26);
  check(info.isNewer(9,26));check(!info.isNewer(10,35));check(!info.isNewer(11,35));check(!info.isNewer(9,25));
  rejects(()->new UpdateRules.Info(0,"0.8.0",url,hash,1024,26));
  rejects(()->new UpdateRules.Info(10,"",url,hash,1024,26));
  rejects(()->new UpdateRules.Info(10,"0.8.0",url,"bad",1024,26));
  rejects(()->new UpdateRules.Info(10,"0.8.0",url,hash,UpdateRules.MAX_BYTES+1,26));
  rejects(()->new UpdateRules.Info(10,"0.8.0",url,hash,0,26));
  for(String bad:new String[]{url.replace("https:","http:"),url.replace("github.com","github.com.evil.test"),url.replace("orbita-flash/","adam-tunnel-pro/"),url+"?download=1",url+"#x",url.replace("github.com/","user@github.com/"),url.replace("github.com/","github.com:444/")})
   rejects(()->new UpdateRules.Info(10,"0.8.0",bad,hash,1024,26));
  check(UpdateRules.redirectAllowed("https://release-assets.githubusercontent.com/path?token=example"));
  check(!UpdateRules.redirectAllowed("http://release-assets.githubusercontent.com/path"));
  check(!UpdateRules.redirectAllowed("https://evil.test/release.apk"));
  check(!UpdateRules.redirectAllowed("https://github.com@evil.test/release.apk"));
  Path file=Files.createTempFile("orbita-update-test-",".apk");
  try {
   byte[] data="example APK payload".getBytes(java.nio.charset.StandardCharsets.UTF_8);Files.write(file,data);
   StringBuilder digest=new StringBuilder();for(byte b:MessageDigest.getInstance("SHA-256").digest(data))digest.append(String.format("%02x",b&255));
   UpdateRules.Info actual=new UpdateRules.Info(10,"0.8.0",url,digest.toString(),data.length,26);
   check(UpdateRules.fileMatches(file.toFile(),actual));
   data[0]^=1;Files.write(file,data);check(!UpdateRules.fileMatches(file.toFile(),actual));
   Files.write(file,new byte[1]);check(!UpdateRules.fileMatches(file.toFile(),actual));
   Files.delete(file);check(!UpdateRules.fileMatches(file.toFile(),actual));
  }finally{Files.deleteIfExists(file);}
  System.out.println("PASS "+checks+" update rules: version, compatibility, host, HTTPS, bounded sizes, checksum and corrupt downloads");
 }
}
