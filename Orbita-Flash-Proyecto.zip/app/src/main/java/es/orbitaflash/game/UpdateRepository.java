package es.orbitaflash.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.os.Build;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

final class UpdateRepository {
 static SharedPreferences prefs(Context c){return c.getSharedPreferences("orbita-updates-v1",Context.MODE_PRIVATE);}
 static long installed(Context c) throws Exception {
  PackageInfo p=c.getPackageManager().getPackageInfo(c.getPackageName(),0);
  return Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;
 }
 static UpdateRules.Info parse(String json)throws Exception {
  JSONObject o=new JSONObject(json);
  if(!UpdateRules.PACKAGE.equals(o.getString("packageName")))throw new IllegalArgumentException("Aplicación incorrecta");
  return new UpdateRules.Info(o.getLong("versionCode"),o.getString("versionName"),o.getString("url"),o.getString("sha256"),o.getLong("size"),o.getInt("minSdk"));
 }
 static String encode(UpdateRules.Info i)throws Exception {
  return new JSONObject().put("packageName",UpdateRules.PACKAGE).put("versionCode",i.versionCode).put("versionName",i.versionName)
   .put("url",i.url).put("sha256",i.sha256).put("size",i.size).put("minSdk",i.minSdk).toString();
 }
 static UpdateRules.Info cached(Context c) {
  try {UpdateRules.Info i=parse(prefs(c).getString("available",""));return i.isNewer(installed(c),Build.VERSION.SDK_INT)?i:null;}catch(Exception e){return null;}
 }
 /** Bounded reads and explicitly checked HTTPS redirects; called off the UI thread. */
 static UpdateRules.Info fetch(Context c)throws Exception {
  String url=UpdateRules.FEED;
  for(int redirect=0;redirect<6;redirect++) {
   if(!UpdateRules.redirectAllowed(url))throw new java.io.IOException("Destino de actualización no permitido");
   HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();
   conn.setInstanceFollowRedirects(false);conn.setConnectTimeout(12000);conn.setReadTimeout(15000);
   conn.setRequestProperty("Accept","application/json");conn.setRequestProperty("Cache-Control","no-cache");
   try {
    int status=conn.getResponseCode();
    if(status==301||status==302||status==303||status==307||status==308) {
     String location=conn.getHeaderField("Location");if(location==null)throw new java.io.IOException("Redirección vacía");
     url=new URL(new URL(url),location).toString();continue;
    }
    if(status==404)return null; // No public release yet. Preserve a previously known update.
    if(status!=200)throw new java.io.IOException("No se pudo consultar la versión");
    ByteArrayOutputStream out=new ByteArrayOutputStream();
    try(InputStream in=conn.getInputStream()) {
     byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){if(out.size()+n>32768)throw new java.io.IOException("Respuesta demasiado grande");out.write(b,0,n);}
    }
    UpdateRules.Info info=parse(out.toString("UTF-8"));
    if(info.isNewer(installed(c),Build.VERSION.SDK_INT)) {prefs(c).edit().putString("available",encode(info)).apply();return info;}
    prefs(c).edit().remove("available").apply();return null;
   }finally{conn.disconnect();}
  }
  throw new java.io.IOException("Demasiadas redirecciones");
 }
 private UpdateRepository(){}
}
