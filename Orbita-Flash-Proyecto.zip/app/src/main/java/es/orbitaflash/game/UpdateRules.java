package es.orbitaflash.game;

import java.io.File;
import java.io.FileInputStream;
import java.net.URI;
import java.security.MessageDigest;
import java.util.Locale;

/** No Android dependencies: shared validation, exercised by the JVM tests. */
public final class UpdateRules {
 public static final long MAX_BYTES = 256L * 1024 * 1024;
 public static final String PACKAGE = "es.orbitaflash.game";
 public static final String FEED = "https://github.com/adam-tunnel-2026/orbita-flash/releases/latest/download/update.json";
 public static final class Info {
  public final long versionCode, size;
  public final int minSdk;
  public final String versionName, url, sha256;
  public Info(long code, String name, String url, String hash, long size, int minSdk) {
   this.versionCode=code;this.versionName=name;this.url=url;this.sha256=hash;
   this.size=size;this.minSdk=minSdk;
   if(code<1 || code>Integer.MAX_VALUE || name==null || name.trim().isEmpty() || name.length()>40 ||
      size<=0 || size>MAX_BYTES || minSdk<26 || minSdk>100 || hash==null || !hash.matches("[a-fA-F0-9]{64}"))
    throw new IllegalArgumentException("Información de actualización no válida");
   URI u=secureUri(url);
   if(!"github.com".equalsIgnoreCase(u.getHost()) ||
      !u.getPath().startsWith("/adam-tunnel-2026/orbita-flash/releases/download/") ||
      !u.getPath().endsWith(".apk") || u.getRawQuery()!=null)
    throw new IllegalArgumentException("La descarga no pertenece a Órbita Flash");
  }
  public boolean isNewer(long installed, int sdk) { return versionCode>installed && sdk>=minSdk; }
 }
 public static URI secureUri(String value) {
  try {
   URI u=new URI(value);
   if(!"https".equalsIgnoreCase(u.getScheme()) || u.getHost()==null || u.getRawUserInfo()!=null ||
      (u.getPort()!=-1 && u.getPort()!=443) || u.getRawFragment()!=null)
    throw new IllegalArgumentException("Se requiere una dirección HTTPS segura");
   return u;
  } catch(java.net.URISyntaxException | NullPointerException e) {throw new IllegalArgumentException("Dirección no válida",e);}
 }
 public static boolean redirectAllowed(String url) {
  try {
   String host=secureUri(url).getHost().toLowerCase(Locale.ROOT);
   return host.equals("github.com") || host.equals("release-assets.githubusercontent.com") || host.equals("objects.githubusercontent.com");
  } catch(IllegalArgumentException e) {return false;}
 }
 public static boolean fileMatches(File file, Info info) throws Exception {
  if(!file.isFile() || file.length()!=info.size)return false;
  MessageDigest digest=MessageDigest.getInstance("SHA-256");
  try(FileInputStream in=new FileInputStream(file)) {
   byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1)digest.update(buffer,0,n);
  }
  StringBuilder hex=new StringBuilder();for(byte b:digest.digest())hex.append(String.format(Locale.ROOT,"%02x",b&255));
  return hex.toString().equalsIgnoreCase(info.sha256);
 }
 private UpdateRules() {}
}
