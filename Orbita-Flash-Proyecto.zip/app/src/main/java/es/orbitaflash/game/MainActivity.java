package es.orbitaflash.game;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.graphics.Color;
import android.view.View;
public class MainActivity extends Activity {
 private WebView game;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  getWindow().setStatusBarColor(Color.rgb(9,14,30));
  getWindow().setNavigationBarColor(Color.rgb(9,14,30));
  game=new WebView(this); game.setBackgroundColor(Color.rgb(9,14,30));
  game.getSettings().setJavaScriptEnabled(true);
  game.getSettings().setDomStorageEnabled(true);
  game.getSettings().setAllowFileAccess(false);
  game.getSettings().setAllowContentAccess(false);
  game.getSettings().setMixedContentMode(0);
  game.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;}
  });
  setContentView(game);
  try(java.io.InputStream input=getAssets().open("index.html")) {
   java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();
   byte[] buf=new byte[8192]; int n; while((n=input.read(buf))!=-1)bytes.write(buf,0,n);
   game.loadDataWithBaseURL("https://orbita-flash.invalid/",bytes.toString("UTF-8"),"text/html","UTF-8",null);
  } catch(java.io.IOException ex){ android.widget.TextView error=new android.widget.TextView(this); error.setText("No se pudo abrir el juego. Vuelve a instalar la APK.");setContentView(error); }
 }
 @Override protected void onPause(){if(game!=null){game.evaluateJavascript("if(typeof state !== 'undefined' && state === 'playing') pause();",null);game.onPause();}super.onPause();}
 @Override protected void onResume(){super.onResume();if(game!=null)game.onResume();}
 @Override public void onBackPressed(){if(game!=null){game.evaluateJavascript("if(state==='playing')pause();",null);}new android.app.AlertDialog.Builder(this).setMessage("¿Salir de Órbita Flash?").setPositiveButton("Salir",(d,w)->finish()).setNegativeButton("Seguir",null).show();}
 @Override protected void onDestroy(){if(game!=null){game.destroy();game=null;}super.onDestroy();}
}
