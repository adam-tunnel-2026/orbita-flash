package es.orbitaflash.game;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.graphics.Color;
import android.view.View;
import android.os.Build;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
public class MainActivity extends Activity {
 private WebView game;
 private UpdateController updates;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  getWindow().setStatusBarColor(Color.rgb(9,14,30));
  getWindow().setNavigationBarColor(Color.rgb(9,14,30));
  game=new WebView(this); game.setBackgroundColor(Color.rgb(9,14,30));
  game.getSettings().setJavaScriptEnabled(true);
  game.getSettings().setDomStorageEnabled(true);
  game.getSettings().setAllowFileAccess(false);
  game.getSettings().setAllowContentAccess(false);
  game.getSettings().setMixedContentMode(0);
  game.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;}
  });
  // Size the WebView inside the system bars, including Android 15 edge-to-edge.
  FrameLayout frame = new FrameLayout(this);
  frame.setBackgroundColor(Color.rgb(9,14,30));
  if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
  else getWindow().getDecorView().setSystemUiVisibility(
    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
  frame.setOnApplyWindowInsetsListener((view, insets) -> {
   int left, top, right, bottom;
   if (Build.VERSION.SDK_INT >= 30) {
    android.graphics.Insets bars = insets.getInsets(
      WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
    left=bars.left;top=bars.top;right=bars.right;bottom=bars.bottom;
   } else {
    left=insets.getSystemWindowInsetLeft();top=insets.getSystemWindowInsetTop();
    right=insets.getSystemWindowInsetRight();bottom=insets.getSystemWindowInsetBottom();
    if (Build.VERSION.SDK_INT >= 28 && insets.getDisplayCutout()!=null) {
     android.view.DisplayCutout cutout=insets.getDisplayCutout();
     left=Math.max(left,cutout.getSafeInsetLeft());top=Math.max(top,cutout.getSafeInsetTop());
     right=Math.max(right,cutout.getSafeInsetRight());bottom=Math.max(bottom,cutout.getSafeInsetBottom());
    }
   }
   view.setPadding(left,top,right,bottom);
   return insets;
  });
  LinearLayout content=new LinearLayout(this);
  content.setOrientation(LinearLayout.VERTICAL);
  try {
   updates=new UpdateController(this,content,()->{
    if(game!=null)game.evaluateJavascript("if(typeof state !== 'undefined' && state === 'playing') pause();",null);
   });
  }catch(RuntimeException ex){
   android.util.Log.e("OrbitaUpdates","Updater unavailable; continuing with the game",ex);
   content.removeAllViews();updates=null;
  }
  content.addView(game,new LinearLayout.LayoutParams(-1,0,1));
  frame.addView(content,new FrameLayout.LayoutParams(-1,-1));
  setContentView(frame);
  frame.requestApplyInsets();
  try(java.io.InputStream input=getAssets().open("index.html")) {
   java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();
   byte[] buf=new byte[8192]; int n; while((n=input.read(buf))!=-1)bytes.write(buf,0,n);
   String html=bytes.toString("UTF-8"), communityUrl="";
   try(java.io.InputStream config=getAssets().open("community-config.json")) {
    java.io.ByteArrayOutputStream configBytes=new java.io.ByteArrayOutputStream();
    while((n=config.read(buf))!=-1)configBytes.write(buf,0,n);
    communityUrl=new org.json.JSONObject(configBytes.toString("UTF-8")).optString("url", "");
   } catch(Exception ignored) {}
   html=html.replace("/* COMMUNITY_CONFIG */", "window.ORBITA_COMMUNITY_URL="+org.json.JSONObject.quote(communityUrl).replace("<","\\u003c")+";");
   game.loadDataWithBaseURL("https://orbita-flash.invalid/",html,"text/html","UTF-8",null);
  } catch(java.io.IOException ex){ android.widget.TextView error=new android.widget.TextView(this); error.setText("No se pudo abrir el juego. Vuelve a instalar la APK.");setContentView(error); }
 }
 @Override protected void onPause(){if(game!=null){game.evaluateJavascript("if(typeof state !== 'undefined' && state === 'playing') pause();",null);game.onPause();}super.onPause();}
 @Override protected void onResume(){super.onResume();if(game!=null)game.onResume();if(updates!=null){boolean show=getIntent().getBooleanExtra("show_update",false);getIntent().removeExtra("show_update");updates.resume(show);}}
 @Override protected void onNewIntent(android.content.Intent intent){super.onNewIntent(intent);setIntent(intent);}
 @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==701&&updates!=null)updates.notificationResult();}
 @Override public void onBackPressed(){if(game!=null){game.evaluateJavascript("if(state==='playing')pause();",null);}new android.app.AlertDialog.Builder(this).setMessage("¿Salir de Órbita Flash?").setPositiveButton("Salir",(d,w)->finish()).setNegativeButton("Seguir",null).show();}
 @Override protected void onDestroy(){if(updates!=null)updates.destroy();if(game!=null){game.destroy();game=null;}super.onDestroy();}
}
