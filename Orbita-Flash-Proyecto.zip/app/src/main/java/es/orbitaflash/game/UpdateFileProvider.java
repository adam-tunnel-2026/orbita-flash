package es.orbitaflash.game;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

/** Grants the Android installer access to exactly one file, read-only. */
public final class UpdateFileProvider extends ContentProvider {
 static File apk(android.content.Context c) {
  File root=c.getExternalFilesDir("updates");
  if(root==null)throw new IllegalStateException("Almacenamiento no disponible");
  return new File(root,"orbita-update.apk");
 }
 static Uri uri(android.content.Context c){return Uri.parse("content://"+c.getPackageName()+".updates/orbita-update.apk");}
 private File resolve(Uri uri)throws FileNotFoundException {
  if(!uri.equals(uri(getContext())))throw new FileNotFoundException("Archivo no permitido");
  File file=apk(getContext());if(!file.isFile())throw new FileNotFoundException("Descarga no encontrada");return file;
 }
 @Override public boolean onCreate(){return true;}
 @Override public String getType(Uri uri){return "application/vnd.android.package-archive";}
 @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException {
  if(!"r".equals(mode))throw new FileNotFoundException("Solo lectura");
  return ParcelFileDescriptor.open(resolve(uri),ParcelFileDescriptor.MODE_READ_ONLY);
 }
 @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort) {
  try {
   File f=resolve(uri);String[] columns=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
   MatrixCursor cursor=new MatrixCursor(columns);Object[] row=new Object[columns.length];
   for(int i=0;i<columns.length;i++)row[i]=OpenableColumns.DISPLAY_NAME.equals(columns[i])?f.getName():OpenableColumns.SIZE.equals(columns[i])?f.length():null;
   cursor.addRow(row);return cursor;
  }catch(FileNotFoundException e){return null;}
 }
 @Override public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
 @Override public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
 @Override public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException();}
}
