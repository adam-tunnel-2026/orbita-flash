package es.orbitaflash.game;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class UpdateController {
 private final Activity activity;
 private final Runnable pauseGame;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final ExecutorService worker=Executors.newSingleThreadExecutor();
 private final Button badge,notices;
 private UpdateRules.Info available;
 private AlertDialog dialog;
 private ProgressBar progress;
 private TextView status;
 private Button action;
 private boolean destroyed,checking,validating,waitingPermission,openAfterCheck,downloadAfterCheck;
 private long lastCheck;
 private final Runnable poller=this::poll;

 UpdateController(Activity activity,LinearLayout container,Runnable pauseGame) {
  this.activity=activity;this.pauseGame=pauseGame;
  LinearLayout bar=new LinearLayout(activity);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setPadding(dp(8),0,dp(8),0);
  badge=new Button(activity);badge.setTextSize(12);badge.setTextColor(Color.rgb(168,255,207));
  badge.setMaxLines(2);badge.setMinWidth(0);
  badge.setContentDescription(L10n.text(activity,"Buscar actualizaciones de Órbita Flash"));
  bar.addView(badge,new LinearLayout.LayoutParams(0,dp(56),1));
  notices=new Button(activity);notices.setText(L10n.text(activity,"Activar avisos"));notices.setTextSize(11);
  notices.setMaxLines(2);notices.setMinWidth(0);
  bar.addView(notices,new LinearLayout.LayoutParams(0,dp(56),1));
  container.addView(bar,new LinearLayout.LayoutParams(-1,-2));
  badge.setOnClickListener(v->{if(available!=null)show(true);else check(true);});
  notices.setOnClickListener(v->requestNotices());
  UpdateJobService.schedule(activity);
  available=UpdateRepository.cached(activity);renderBadge();
 }
 private int dp(int value){return Math.round(activity.getResources().getDisplayMetrics().density*value);}
 void resume(boolean showRequested) {
  notices.setVisibility(UpdateJobService.notificationsAllowed(activity)?View.GONE:View.VISIBLE);
  if(available==null)available=UpdateRepository.cached(activity);
  renderBadge();
  if(waitingPermission){waitingPermission=false;if(activity.getPackageManager().canRequestPackageInstalls())verify(true);}
  if(showRequested) {if(available!=null)show(true);else check(true,true);}
  else if(System.currentTimeMillis()-lastCheck>5*60*1000)check(false);
  handler.removeCallbacks(poller);
  if(downloadId()!=-1)handler.post(poller);
 }
 void check(boolean requested) {
  check(requested,false);
 }
 private void check(boolean requested,boolean downloadRequested) {
  if(checking){openAfterCheck|=requested;downloadAfterCheck|=downloadRequested;return;}
  checking=true;openAfterCheck=requested;downloadAfterCheck=downloadRequested;lastCheck=System.currentTimeMillis();
  if(requested)toast(L10n.text(activity,"Buscando actualizaciones…"));
  worker.execute(()->{
   boolean failed=false;
   try {UpdateRepository.fetch(activity);}catch(Exception e){failed=true;}
   final boolean error=failed;
   handler.post(()->{
    if(destroyed)return;checking=false;available=UpdateRepository.cached(activity);renderBadge();
    if(available!=null){UpdateJobService.notifyUpdate(activity,available);if(openAfterCheck)show(downloadAfterCheck);}
    else if(openAfterCheck)toast(error?L10n.text(activity,"No se pudo comprobar. Revisa tu conexión y vuelve a intentarlo."):L10n.text(activity,"No hay una actualización publicada para este móvil."));
    openAfterCheck=false;downloadAfterCheck=false;
   });
  });
 }
 private void renderBadge() {
  badge.setText(available==null?L10n.text(activity,"Actualizaciones"):L10n.text(activity,"① Actualizar · ")+available.versionName);
  badge.setContentDescription(available==null?L10n.text(activity,"Buscar actualizaciones"):L10n.text(activity,"Una nueva actualización disponible"));
 }
 private void requestNotices() {
  if(Build.VERSION.SDK_INT>=33&&activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
   activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},701);
  else {
   Intent i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,activity.getPackageName());
   activity.startActivity(i);
  }
 }
 void notificationResult() {
  notices.setVisibility(UpdateJobService.notificationsAllowed(activity)?View.GONE:View.VISIBLE);
  if(available!=null)UpdateJobService.notifyUpdate(activity,available);
 }
 private void show(boolean downloadRequested) {
  if(destroyed||available==null)return;
  if(dialog!=null&&dialog.isShowing()){if(downloadRequested)start();return;}
  pauseGame.run();
  LinearLayout layout=new LinearLayout(activity);layout.setOrientation(LinearLayout.VERTICAL);layout.setPadding(dp(22),dp(12),dp(22),dp(12));
  TextView explanation=new TextView(activity);explanation.setText("Órbita Flash "+available.versionName+L10n.text(activity,"\nSe instalará sobre el juego actual. No desinstales la aplicación."));
  layout.addView(explanation);
  progress=new ProgressBar(activity,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);progress.setProgress(0);
  progress.setProgressTintList(ColorStateList.valueOf(Color.rgb(30,215,96)));
  progress.setProgressBackgroundTintList(ColorStateList.valueOf(Color.rgb(53,70,65)));
  LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(28));p.topMargin=dp(20);p.bottomMargin=dp(10);layout.addView(progress,p);
  status=new TextView(activity);status.setText(L10n.text(activity,"Lista para descargar · ")+mb(available.size)+" MB");status.setTextSize(16);layout.addView(status);
  action=new Button(activity);action.setText(L10n.text(activity,"Descargar actualización"));layout.addView(action,new LinearLayout.LayoutParams(-1,dp(54)));
  action.setOnClickListener(v->start());
  dialog=new AlertDialog.Builder(activity).setTitle(L10n.text(activity,"① Nueva actualización")).setView(layout).setNegativeButton(L10n.text(activity,"Cerrar"),null).create();
  dialog.show();
  if(downloadRequested)start();else if(downloadId()!=-1)poll();
 }
 private long downloadId(){return UpdateRepository.prefs(activity).getLong("download-id",-1);}
 private static String mb(long n){return String.format(Locale.getDefault(),"%.1f",n/1048576.0);}
 private void start() {
  if(available==null)return;
  if(downloadId()!=-1){poll();return;}
  try {
   File file=UpdateFileProvider.apk(activity);
   if(file.exists()&&!file.delete())throw new java.io.IOException(L10n.text(activity,"No se pudo preparar el archivo"));
   DownloadManager.Request request=new DownloadManager.Request(Uri.parse(available.url));
   request.setTitle(L10n.text(activity,"Actualización de Órbita Flash"));request.setDescription(L10n.text(activity,"Descargando la nueva versión"));
   request.setMimeType("application/vnd.android.package-archive");
   request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
   request.setDestinationInExternalFilesDir(activity,"updates","orbita-update.apk");
   request.setAllowedOverMetered(true);request.setAllowedOverRoaming(false);
   // Persist metadata first; do not change this pending release if a new feed arrives.
   if(!UpdateRepository.prefs(activity).edit().putString("pending-info",UpdateRepository.encode(available)).putBoolean("install-offered",false).commit())throw new java.io.IOException(L10n.text(activity,"No se pudo guardar el estado"));
   long id=activity.getSystemService(DownloadManager.class).enqueue(request);
   if(!UpdateRepository.prefs(activity).edit().putLong("download-id",id).commit()) {
    activity.getSystemService(DownloadManager.class).remove(id);throw new java.io.IOException(L10n.text(activity,"No se pudo guardar la descarga"));
   }
   handler.removeCallbacks(poller);poll();
  }catch(Exception e){fail(L10n.text(activity,"No se pudo iniciar la descarga. Revisa la conexión y el espacio libre."));}
 }
 private void poll() {
  if(destroyed||validating)return;long id=downloadId();if(id==-1)return;
  try(Cursor cursor=activity.getSystemService(DownloadManager.class).query(new DownloadManager.Query().setFilterById(id))) {
   if(cursor==null||!cursor.moveToFirst()){resetDownload();fail(L10n.text(activity,"La descarga ya no está disponible. Puedes volver a descargarla."));return;}
   int state=cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
   long done=cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
   long total=cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
   if(state==DownloadManager.STATUS_FAILED){resetDownload();fail(L10n.text(activity,"La descarga no se completó. Revisa la conexión y el espacio libre e inténtalo de nuevo."));return;}
   if(state==DownloadManager.STATUS_SUCCESSFUL) {
    // A changed application version means this pending APK was already installed.
    UpdateRules.Info info=UpdateRepository.parse(UpdateRepository.prefs(activity).getString("pending-info",""));
    if(info.versionCode<=UpdateRepository.installed(activity)){resetDownload();return;}
    verify(false);return;
   }
   if(total>UpdateRules.MAX_BYTES||done>UpdateRules.MAX_BYTES){resetDownload();fail(L10n.text(activity,"El archivo supera el tamaño permitido."));return;}
   if(status!=null) {
    boolean known=total>0;progress.setIndeterminate(!known);if(known)progress.setProgress((int)Math.min(99,done*100/total));
    status.setText(state==DownloadManager.STATUS_PAUSED?L10n.text(activity,"Descarga en espera de conexión…"):
     L10n.text(activity,"Descargando: ")+(known?(Math.min(99,done*100/total)+" % · "):"")+mb(Math.max(0,done))+(known?L10n.text(activity," de ")+mb(total):"")+" MB");
    action.setEnabled(false);action.setText(L10n.text(activity,"Descargando…"));
   }
   handler.removeCallbacks(poller);handler.postDelayed(poller,500);
  }catch(Exception e){resetDownload();fail(L10n.text(activity,"No se pudo recuperar la descarga. Inténtalo de nuevo."));}
 }
 private void verify(boolean installAfter) {
  if(validating||destroyed)return;validating=true;
  if(status!=null){status.setText(L10n.text(activity,"Comprobando la descarga y su firma…"));progress.setIndeterminate(true);action.setEnabled(false);}
  worker.execute(()->{
   String error=null;
   try {
    UpdateRules.Info info=UpdateRepository.parse(UpdateRepository.prefs(activity).getString("pending-info",""));
    File file=UpdateFileProvider.apk(activity);
    if(!info.isNewer(UpdateRepository.installed(activity),Build.VERSION.SDK_INT)||!UpdateRules.fileMatches(file,info))throw new SecurityException(L10n.text(activity,"Archivo incompleto o modificado"));
    PackageManager pm=activity.getPackageManager();
    int flags=Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES;
    PackageInfo candidate=pm.getPackageArchiveInfo(file.getAbsolutePath(),flags),current=pm.getPackageInfo(activity.getPackageName(),flags);
    if(candidate==null||!activity.getPackageName().equals(candidate.packageName)||
       (Build.VERSION.SDK_INT>=28?candidate.getLongVersionCode():candidate.versionCode)!=info.versionCode||
       candidate.applicationInfo==null||candidate.applicationInfo.minSdkVersion>Build.VERSION.SDK_INT||
       !sameSignatures(current,candidate))throw new SecurityException(L10n.text(activity,"La firma no coincide con tu juego. No desinstales la aplicación"));
   }catch(Exception e){error=e instanceof SecurityException?e.getMessage():L10n.text(activity,"No se pudo verificar la actualización");}
   final String problem=error;
   handler.post(()->{
    if(destroyed)return;validating=false;
    if(problem!=null){resetDownload();fail(problem+L10n.text(activity,". Tus datos actuales no se han cambiado."));return;}
    if(status!=null){progress.setIndeterminate(false);progress.setProgress(100);status.setText(L10n.text(activity,"Descarga completa · 100 %\nLista para instalar"));action.setEnabled(true);action.setText(L10n.text(activity,"Instalar actualización"));action.setOnClickListener(v->verify(true));}
    if(installAfter)install();
    // Only open Android's installer while this download dialog is visible.
    else if(dialog!=null&&dialog.isShowing()&&activity.hasWindowFocus()&&!UpdateRepository.prefs(activity).getBoolean("install-offered",false)) {
     UpdateRepository.prefs(activity).edit().putBoolean("install-offered",true).apply();install();
    }
   });
  });
 }
 private boolean sameSignatures(PackageInfo a,PackageInfo b) {
  Signature[] x=Build.VERSION.SDK_INT>=28?(a.signingInfo==null?null:a.signingInfo.getApkContentsSigners()):a.signatures;
  Signature[] y=Build.VERSION.SDK_INT>=28?(b.signingInfo==null?null:b.signingInfo.getApkContentsSigners()):b.signatures;
  return x!=null&&y!=null&&x.length>0&&x.length==y.length&&Arrays.asList(x).containsAll(Arrays.asList(y));
 }
 private void install() {
  try {
   if(!activity.getPackageManager().canRequestPackageInstalls()) {
    new AlertDialog.Builder(activity).setTitle(L10n.text(activity,"Permitir esta actualización"))
     .setMessage(L10n.text(activity,"Android necesita que autorices a Órbita Flash para instalar su actualización. Activa el permiso y vuelve al juego."))
     .setPositiveButton(L10n.text(activity,"Abrir ajustes"),(d,w)->{waitingPermission=true;activity.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+activity.getPackageName())));})
     .setNegativeButton(L10n.text(activity,"Ahora no"),null).show();return;
   }
   Uri uri=UpdateFileProvider.uri(activity);
   Intent i=new Intent(Intent.ACTION_INSTALL_PACKAGE).setDataAndType(uri,"application/vnd.android.package-archive")
    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
   i.setClipData(ClipData.newRawUri(L10n.text(activity,"Actualización de Órbita Flash"),uri));
   activity.startActivity(i);
  }catch(Exception e){fail(L10n.text(activity,"No se pudo abrir el instalador. Puedes volver a pulsar Instalar."),false);}
 }
 private void resetDownload() {
  long id=downloadId();if(id!=-1)activity.getSystemService(DownloadManager.class).remove(id);
  UpdateRepository.prefs(activity).edit().remove("download-id").remove("pending-info").remove("install-offered").apply();
  try{UpdateFileProvider.apk(activity).delete();}catch(Exception ignored){}
 }
 private void fail(String message){fail(message,true);}
 private void fail(String message,boolean retry) {
  if(status==null||dialog==null||!dialog.isShowing()){toast(message);return;}
  progress.setIndeterminate(false);status.setText(message);action.setEnabled(true);
  action.setText(retry?L10n.text(activity,"Volver a descargar"):L10n.text(activity,"Instalar actualización"));action.setOnClickListener(v->{if(retry)start();else verify(true);});
 }
 private void toast(String text){Toast.makeText(activity,text,Toast.LENGTH_LONG).show();}
 void destroy() {
  destroyed=true;handler.removeCallbacksAndMessages(null);worker.shutdownNow();
  if(dialog!=null)dialog.dismiss();
 }
}
