package es.orbitaflash.game;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public final class UpdateJobService extends JobService {
 static final String CHANNEL="orbita-updates";
 static final int JOB=70601,NOTICE=70602;
 private volatile boolean stopped;
 static boolean notificationsAllowed(Context c) {
  try {
   NotificationManager nm=c.getSystemService(NotificationManager.class);
   return nm!=null && (Build.VERSION.SDK_INT<33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)
    && nm.areNotificationsEnabled();
  }catch(SecurityException e){return false;}
 }
 static void schedule(Context c) {
  // Background checks are optional: an OS restriction must never block the game.
  try {
   NotificationManager nm=c.getSystemService(NotificationManager.class);
   if(nm!=null)nm.createNotificationChannel(new NotificationChannel(CHANNEL,L10n.text(c,"Actualizaciones del juego"),NotificationManager.IMPORTANCE_DEFAULT));
   JobScheduler scheduler=c.getSystemService(JobScheduler.class);
   if(scheduler==null)return;
   if(scheduler.getPendingJob(JOB)==null) {
    int result=scheduler.schedule(new JobInfo.Builder(JOB,new ComponentName(c,UpdateJobService.class))
     .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(6*60*60*1000L).setPersisted(true).build());
    if(result!=JobScheduler.RESULT_SUCCESS)android.util.Log.w("OrbitaUpdates","Background update scheduling unavailable");
   }
  }catch(RuntimeException e){android.util.Log.w("OrbitaUpdates","Background checks unavailable; foreground checks remain enabled",e);}
 }
 static void notifyUpdate(Context c,UpdateRules.Info info) {
  if(!notificationsAllowed(c)||UpdateRepository.prefs(c).getLong("notified",0)>=info.versionCode)return;
  Intent intent=new Intent(c,MainActivity.class).putExtra("show_update",true).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
  PendingIntent pending=PendingIntent.getActivity(c,NOTICE,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download_done)
   .setContentTitle(L10n.text(c,"① Nueva actualización disponible")).setContentText("Órbita Flash "+info.versionName+L10n.text(c," · Toca para actualizar"))
   .setNumber(1).setAutoCancel(true).setContentIntent(pending).build();
  try {
   c.getSystemService(NotificationManager.class).notify(NOTICE,n);
   UpdateRepository.prefs(c).edit().putLong("notified",info.versionCode).apply();
  }catch(SecurityException e){android.util.Log.w("OrbitaUpdates","Notification permission unavailable",e);}
 }
 @Override public boolean onStartJob(JobParameters params) {
  stopped=false;
  new Thread(()->{
   boolean retry=false;
   try{UpdateRules.Info info=UpdateRepository.fetch(this);if(info!=null&&!stopped)notifyUpdate(this,info);}catch(Exception e){retry=true;}
   final boolean needsRetry=retry;
   new android.os.Handler(getMainLooper()).post(()->{if(!stopped)jobFinished(params,needsRetry);});
  },"orbita-update-check").start();return true;
 }
 @Override public boolean onStopJob(JobParameters params){stopped=true;return true;}
}
