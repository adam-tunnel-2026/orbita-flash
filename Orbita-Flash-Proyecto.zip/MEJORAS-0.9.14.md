Órbita Flash 0.9.14 — Primera mejora visual

- Área de juego ampliada en móviles, para que la órbita se vea más grande.
- Márgenes laterales reducidos, manteniendo el espacio para obstáculos.
- Se conserva la física, combos, controles, comunidad y guardado local.
- versionCode 27 para actualización sobre 26, con la misma firma permanente configurada en GitHub.
- No se modifica el servidor ni otros proyectos.
