'use strict';
const {parentPort,workerData}=require('node:worker_threads');
try{parentPort.postMessage(require('./game-core.js').verify(workerData.seed,workerData.events,workerData.steps,workerData.rules));}catch(e){parentPort.postMessage({error:e.message});}
