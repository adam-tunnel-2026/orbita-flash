'use strict';
const http=require('node:http'),crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path');
const {Worker}=require('node:worker_threads');const {RULES}=require('./game-core.js');
const {HOUR,MIN_SCORE,MODE,hourStart,cityKey,rank}=require('./competition.js');
const SESSION_TTL=7200000,PORT=Number(process.env.PORT||8788),DATA=process.env.DATA_DIR||path.join(__dirname,'data');
fs.mkdirSync(DATA,{recursive:true,mode:0o700});const keyFile=path.join(DATA,'secret');if(!fs.existsSync(keyFile))fs.writeFileSync(keyFile,crypto.randomBytes(32),{mode:0o600});const key=fs.readFileSync(keyFile);
// New format deliberately excludes the former rolling leaderboard.
const dbFile=path.join(DATA,'competition.json');let state={rows:[],history:[],lastClosedHour:hourStart(Date.now())-HOUR};
if(fs.existsSync(dbFile)){state=JSON.parse(fs.readFileSync(dbFile,'utf8'));if(!Array.isArray(state.rows)||!Array.isArray(state.history)||!Number.isFinite(state.lastClosedHour))throw Error('Base de datos no válida');}
const buckets=new Map();let workers=0;
function persist(){const tmp=dbFile+'.tmp';fs.writeFileSync(tmp,JSON.stringify(state),{mode:0o600});fs.renameSync(tmp,dbFile);}
function prune(){const n=Date.now(),current=hourStart(n);let changed=false;
 // Expire the old rolling-format names too; they never enter the new competition.
 const legacyFile=path.join(DATA,'towns.json');if(fs.existsSync(legacyFile)){const old=JSON.parse(fs.readFileSync(legacyFile,'utf8'));if(!Array.isArray(old))throw Error('Base anterior no válida');const live=old.filter(r=>r.expiresAt>n);if(live.length!==old.length)fs.writeFileSync(legacyFile,JSON.stringify(live),{mode:0o600});}

 // Preserve each completed hour once, including a tie's original acceptance order.
 const first=Math.max(state.lastClosedHour+HOUR,current-24*HOUR);
 for(let start=first;start<current;start+=HOUR){state.history.push({roundStart:start,roundEnd:start+HOUR,towns:rank(state.rows,start).slice(0,3)});changed=true;}
 if(state.lastClosedHour<current-HOUR){state.lastClosedHour=current-HOUR;changed=true;}
 const history=state.history.filter(h=>h.roundEnd>n-24*HOUR);
 const rows=state.rows.filter(r=>r.expiresAt+SESSION_TTL>n).map(r=>r.expiresAt<=n?{id:r.id,expiresAt:r.expiresAt}:r);
 if(JSON.stringify(rows)!==JSON.stringify(state.rows)||history.length!==state.history.length)changed=true;
 state.rows=rows;state.history=history;if(changed)persist();for(let [k,v] of buckets)if(v.reset<n)buckets.delete(k);
}
function board(){const now=Date.now(),roundStart=hourStart(now);return {mode:MODE,minScore:MIN_SCORE,now,roundStart,roundEnd:roundStart+HOUR,towns:rank(state.rows,roundStart),previous:state.history.find(h=>h.roundStart===roundStart-HOUR)||null,history:state.history.filter(h=>h.roundEnd>now-24*HOUR&&h.roundEnd<=roundStart).sort((a,b)=>b.roundStart-a.roundStart).slice(0,24)};}
function normalizeCity(value){if(typeof value!=='string')throw Error('Escribe el pueblo o ciudad');const city=value.normalize('NFC').trim().replace(/\s+/gu,' ');if([...city].length<2||[...city].length>40||!/^\p{L}[\p{L}\p{M} .’'\-]*$/u.test(city))throw Error('Usa de 2 a 40 caracteres: letras, espacios, puntos, guiones o apóstrofos');
 const tokens=city.normalize('NFD').replace(/\p{M}/gu,'').toLowerCase().split(/[^a-z]+/);const blocked=new Set(['puta','puto','putas','putos','mierda','gilipollas','cabron','cabrones','cojones','follar','fuck','shit','nazi']);if(tokens.some(t=>blocked.has(t)))throw Error('Ese nombre no se puede publicar');return city;}
function sign(data){const payload=Buffer.from(JSON.stringify(data)).toString('base64url');return payload+'.'+crypto.createHmac('sha256',key).update(payload).digest('base64url');}
function decode(token){if(typeof token!=='string'||token.length>2000)throw Error('Sesión no válida');const parts=token.split('.');if(parts.length!==2)throw Error('Sesión no válida');let expected=crypto.createHmac('sha256',key).update(parts[0]).digest(),given=Buffer.from(parts[1],'base64url');if(given.length!==expected.length||!crypto.timingSafeEqual(given,expected))throw Error('Sesión no válida');const d=JSON.parse(Buffer.from(parts[0],'base64url'));if(d.rules!==RULES||!Number.isInteger(d.seed)||!Number.isFinite(d.time)||Date.now()-d.time>SESSION_TTL||d.time>Date.now()+1000)throw Error('Sesión caducada');return d;}
function rate(req,kind,limit){const ip=req.headers['cf-connecting-ip']||req.socket.remoteAddress,k=kind+':'+ip,n=Date.now();let b=buckets.get(k);if(!b||b.reset<n){b={n:0,reset:n+60000};buckets.set(k,b);}if(++b.n>limit)throw Object.assign(Error('Demasiadas solicitudes; prueba dentro de un minuto'),{status:429});}
function replay(input){if(workers>=2)return Promise.reject(Object.assign(Error('Servidor ocupado; vuelve a intentarlo'),{status:503}));workers++;return new Promise((resolve,reject)=>{const w=new Worker(path.join(__dirname,'verify-worker.js'),{workerData:input});const timer=setTimeout(()=>{w.terminate();reject(Error('La verificación tardó demasiado'));},5000);let settled=false;w.once('message',r=>{settled=true;r.error?reject(Error(r.error)):resolve(r);});w.once('error',reject);w.once('exit',()=>{clearTimeout(timer);workers--;if(!settled)reject(Error('No se pudo verificar la partida'));});});}
function body(req){return new Promise((resolve,reject)=>{let text='',size=0;req.on('data',b=>{size+=b.length;if(size>524288){reject(Object.assign(Error('Partida demasiado grande'),{status:413}));req.destroy();}else text+=b;});req.on('end',()=>{try{resolve(JSON.parse(text))}catch{reject(Error('JSON no válido'))}});req.on('error',reject);});}
function send(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));}
const server=http.createServer(async(req,res)=>{try{
 if(req.method==='OPTIONS')return send(res,204,{});const url=new URL(req.url,'http://localhost');prune();
 if(url.pathname==='/health'&&req.method==='GET')return send(res,200,{ok:true,rules:RULES,competition:MODE,minScore:MIN_SCORE,historyHours:24});
 if(url.pathname==='/rounds'&&req.method==='POST'){rate(req,'start',30);const data=await body(req);if(data.rules!==RULES)throw Error('Actualiza el juego');const session={id:crypto.randomUUID(),seed:crypto.randomBytes(4).readUInt32LE(),time:Date.now(),rules:RULES};return send(res,200,{seed:session.seed,token:sign(session),rules:RULES,competition:MODE});}
 if(url.pathname==='/towns'&&req.method==='GET'){rate(req,'list',120);return send(res,200,board());}
 if(url.pathname==='/towns'&&req.method==='POST'){rate(req,'publish',15);const data=await body(req),session=decode(data.token),city=normalizeCity(data.city);let row=state.rows.find(r=>r.id===session.id);if(row&&row.expiresAt<=Date.now())throw Error('Esta marca ya caducó. Juega una ronda nueva');if(row)return send(res,200,{ok:true,city:row.city,score:row.score,expiresAt:row.expiresAt,roundStart:row.roundStart,now:Date.now()});
 if(!Number.isInteger(data.steps)||data.steps/120*1000>Date.now()-session.time+1500)throw Error('Tiempo de partida no válido');const checked=await replay({seed:session.seed,events:data.events,steps:data.steps});row=state.rows.find(r=>r.id===session.id);if(row&&row.expiresAt<=Date.now())throw Error('Esta marca ya caducó. Juega una ronda nueva');if(row)return send(res,200,{ok:true,city:row.city,score:row.score,expiresAt:row.expiresAt,roundStart:row.roundStart,now:Date.now()});
 if(state.rows.length>=10000)throw Object.assign(Error('Marcador lleno temporalmente'),{status:503});prune();const now=Date.now(),roundStart=hourStart(now);row={id:session.id,city,score:checked.score,createdAt:now,roundStart,expiresAt:roundStart+HOUR};state.rows.push(row);persist();return send(res,200,{ok:true,city:row.city,score:row.score,expiresAt:row.expiresAt,roundStart:row.roundStart,now:Date.now()});}
 send(res,404,{error:'Ruta no encontrada'});
 }catch(e){send(res,e.status||400,{error:e.message||'No se pudo procesar la solicitud'});}});
if(require.main===module){server.listen(PORT,'127.0.0.1',()=>console.log('Órbita Flash escuchando en 127.0.0.1:'+PORT));setInterval(prune,60000).unref();}
module.exports={normalizeCity,cityKey,server};
