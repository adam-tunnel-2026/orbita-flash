/* Shared deterministic rules for the client and score verification. */
(function(root){
'use strict';
const HZ=120, DT=1/HZ, RULES='orbita-v07', LEGACY_RULES='orbita-v06';
class Round {
 constructor(seed,rules=RULES){this.comboEnabled=rules===RULES;this.bonus=0;this.baseHalf=0;this.orbit=0;this.precise=0;this.recent=[];this.rhythmStart=null;this.lastPrecise=null;this.rhythmReady=0;this.boosts=[0,0];this.clean=true;this.milestone=false;this.pending=[];this.feedback=[];this.seed=seed>>>0;this.randomState=this.seed;this.steps=0;this.angle=-Math.PI/2;this.lane=1;this.visualLane=1;this.spawn=2;this.coinSpawn=1;this.obstacles=[];this.pickups=[];this.invincible=1;this.dead=false;this.revived=false;this.coins=0;this.events=[];}
 get seconds(){return this.steps/HZ} get score(){return this.comboEnabled?Math.floor(this.baseHalf/2)+this.bonus:Math.floor(this.steps*5/HZ)}
 random(){this.randomState=(Math.imul(1664525,this.randomState)+1013904223)>>>0;return this.randomState/4294967296;}
 switch(){if(this.dead)return false;if(this.comboEnabled&&this.invincible<=0&&Math.abs(this.visualLane-this.lane)<.12){
  const obstacle=this.obstacles.find(o=>o.l===this.lane&&o.a>this.angle&&!o.rewarded&&this.hits(o,this.angle+(.7+Math.min(this.seconds/140,.65))*.19,this.lane));
  if(obstacle&&!this.pending.some(p=>p.obstacle===obstacle)){
   const lastFrame=this.hits(obstacle,this.angle+(.7+Math.min(this.seconds/140,.65))*.065,this.lane);
   this.pending.push({obstacle,lane:1-this.lane,lastFrame});
  }
 }
 this.lane=1-this.lane;
 this.pending=this.pending.filter(p=>p.lane===this.lane);
 this.events.push([this.steps,'s']);return true;}
 revive(){if(!this.dead||this.revived)return false;this.revived=true;this.dead=false;this.obstacles=[];this.pending=[];this.orbit=0;this.spawn=2.2;this.invincible=2;this.events.push([this.steps,'r']);return true;}
 position(a,l){const radius=115.2+(l-.5)*48.384;return {x:Math.cos(a)*radius,y:Math.sin(a)*radius};}
 hits(o,angle=this.angle,lane=this.visualLane){let p=this.position(angle,lane),q=this.position(o.a,o.l),dx=p.x-q.x,dy=p.y-q.y,cs=Math.cos(o.a),sn=Math.sin(o.a);let x=Math.abs(dx*cs+dy*sn),y=Math.abs(-dx*sn+dy*cs);return Math.hypot(Math.max(0,x-9),Math.max(0,y-9))<8;}
 reward(name,points=0,coins=0){
  this.bonus+=points;this.coins+=coins;this.feedback.push(name);
 }
 combos(delta){
  this.orbit+=delta;
  if(this.orbit>=2*Math.PI){
   this.orbit-=2*Math.PI;this.reward('Órbita Limpia',30,2);
  }
  this.pending=this.pending.filter(p=>{
   if(this.angle<p.obstacle.a+.06)return true;
   p.obstacle.rewarded=true;
   if(p.lastFrame){this.invincible=1;this.reward('Salvación',15);}
   else this.reward('Cambio Relámpago',20);
   const now=this.steps, previous=this.lastPrecise;
   this.lastPrecise=now;
   if(previous===null||now-previous>4*HZ)this.rhythmStart=now;
   this.recent=this.recent.filter(step=>now-step<3*HZ);
   this.recent.push(now);
   if(this.recent.length===3){this.reward('Triple Esquiva',25);this.recent=[];}
   if(++this.precise===5){this.precise=0;this.boosts[0]=now+8*HZ;this.reward('Racha Perfecta');}
   if(now-this.rhythmStart>=10*HZ&&now>=this.rhythmReady){
    this.boosts[1]=now+5*HZ;this.rhythmReady=now+10*HZ;this.reward('Giro Maestro');
   }
   return false;
  });
  if(this.clean&&!this.milestone&&this.score>=200){
   this.milestone=true;this.reward('Órbita Infinita',80,10);
  }
 }
 get multiplier(){return this.steps<this.boosts[1]?2:this.steps<this.boosts[0]?1.5:1;}
 tick(){if(this.dead)return;this.feedback=[];
 const multiplier=this.multiplier;
 this.steps++;
 if(this.comboEnabled&&this.steps%(HZ/5)===0)this.baseHalf+=multiplier*2;
 this.invincible=Math.max(0,this.invincible-DT);const delta=(.7+Math.min(this.seconds/140,.65))*DT;this.angle+=delta;this.visualLane+=Math.sign(this.lane-this.visualLane)*Math.min(Math.abs(this.lane-this.visualLane),DT/.09);this.spawn-=DT;this.coinSpawn-=DT;
 if(this.spawn<=0){this.obstacles.push({a:this.angle+1.8,l:this.random()<.5?0:1});this.spawn=Math.max(1.3,2.2-this.seconds/110);}
 if(this.coinSpawn<=0){let a=this.angle+1.3,l=this.random()<.5?0:1;if(!this.obstacles.some(o=>Math.abs(o.a-a)<.35&&o.l===l))this.pickups.push({a,l});this.coinSpawn=1.4;}
 for(let o of this.obstacles)if(Math.abs(o.a-this.angle)<.65&&this.hits(o)&&this.invincible<=0){this.dead=true;this.clean=false;this.precise=0;this.recent=[];this.rhythmStart=null;this.lastPrecise=null;this.boosts=[0,0];return;}
 for(let p of this.pickups){let q=this.position(p.a,p.l),v=this.position(this.angle,this.visualLane);if(!p.used&&Math.abs(this.angle-p.a)<.5&&Math.hypot(v.x-q.x,v.y-q.y)<18){p.used=true;this.coins++;}}
 if(this.comboEnabled)this.combos(delta);
 this.obstacles=this.obstacles.filter(o=>o.a>this.angle-.65);this.pickups=this.pickups.filter(p=>p.a>this.angle-.5&&!p.used);
 }
}
function verify(seed,events,steps,rules=RULES){
 if(!Number.isInteger(steps)||steps<(rules===LEGACY_RULES?2400:1)||steps>HZ*3600||!Array.isArray(events)||events.length>20000)throw Error('Partida no válida');
 let g=new Round(seed,rules),last=-1;for(let e of events){if(!Array.isArray(e)||e.length!==2||!Number.isInteger(e[0])||e[0]<last||e[0]>steps||!['s','r'].includes(e[1]))throw Error('Registro no válido');last=e[0];}
 let i=0;for(let t=0;t<=steps;t++){while(i<events.length&&events[i][0]===t){let ok=events[i][1]==='s'?g.switch():g.revive();if(!ok)throw Error('Movimiento imposible');i++;}if(t===steps)break;if(g.dead)throw Error('La partida ya había terminado');g.tick();}
 if(!g.dead||g.score<100)throw Error('La ronda debe terminar con al menos 100 puntos');
 return {score:g.score,seconds:g.seconds,revived:g.revived};
}
const api={Round,verify,HZ,RULES,LEGACY_RULES};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.OrbitaRules=api;
})(typeof window!=='undefined'?window:globalThis);
