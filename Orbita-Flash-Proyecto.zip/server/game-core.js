/* Shared deterministic rules for the client and score verification. */
(function(root){
'use strict';
const HZ=120, DT=1/HZ, RULES='orbita-v06';
class Round {
 constructor(seed){this.seed=seed>>>0;this.randomState=this.seed;this.steps=0;this.angle=-Math.PI/2;this.lane=1;this.visualLane=1;this.spawn=2;this.coinSpawn=1;this.obstacles=[];this.pickups=[];this.invincible=1;this.dead=false;this.revived=false;this.coins=0;this.events=[];}
 get seconds(){return this.steps/HZ} get score(){return Math.floor(this.steps*5/HZ)}
 random(){this.randomState=(Math.imul(1664525,this.randomState)+1013904223)>>>0;return this.randomState/4294967296;}
 switch(){if(this.dead)return false;this.lane=1-this.lane;this.events.push([this.steps,'s']);return true;}
 revive(){if(!this.dead||this.revived)return false;this.revived=true;this.dead=false;this.obstacles=[];this.spawn=2.2;this.invincible=2;this.events.push([this.steps,'r']);return true;}
 position(a,l){const radius=115.2+(l-.5)*48.384;return {x:Math.cos(a)*radius,y:Math.sin(a)*radius};}
 hits(o){let p=this.position(this.angle,this.visualLane),q=this.position(o.a,o.l),dx=p.x-q.x,dy=p.y-q.y,cs=Math.cos(o.a),sn=Math.sin(o.a);let x=Math.abs(dx*cs+dy*sn),y=Math.abs(-dx*sn+dy*cs);return Math.hypot(Math.max(0,x-9),Math.max(0,y-9))<8;}
 tick(){if(this.dead)return;this.steps++;this.invincible=Math.max(0,this.invincible-DT);this.angle+=(.7+Math.min(this.seconds/140,.65))*DT;this.visualLane+=Math.sign(this.lane-this.visualLane)*Math.min(Math.abs(this.lane-this.visualLane),DT/.09);this.spawn-=DT;this.coinSpawn-=DT;
 if(this.spawn<=0){this.obstacles.push({a:this.angle+1.8,l:this.random()<.5?0:1});this.spawn=Math.max(1.3,2.2-this.seconds/110);}
 if(this.coinSpawn<=0){let a=this.angle+1.3,l=this.random()<.5?0:1;if(!this.obstacles.some(o=>Math.abs(o.a-a)<.35&&o.l===l))this.pickups.push({a,l});this.coinSpawn=1.4;}
 for(let o of this.obstacles)if(Math.abs(o.a-this.angle)<.65&&this.hits(o)&&this.invincible<=0){this.dead=true;return;}
 for(let p of this.pickups){let q=this.position(p.a,p.l),v=this.position(this.angle,this.visualLane);if(!p.used&&Math.abs(this.angle-p.a)<.5&&Math.hypot(v.x-q.x,v.y-q.y)<18){p.used=true;this.coins++;}}
 this.obstacles=this.obstacles.filter(o=>o.a>this.angle-.65);this.pickups=this.pickups.filter(p=>p.a>this.angle-.5&&!p.used);
 }
}
function verify(seed,events,steps){
 if(!Number.isInteger(steps)||steps<2400||steps>HZ*3600||!Array.isArray(events)||events.length>20000)throw Error('Partida no válida');
 let g=new Round(seed),last=-1;for(let e of events){if(!Array.isArray(e)||e.length!==2||!Number.isInteger(e[0])||e[0]<last||e[0]>steps||!['s','r'].includes(e[1]))throw Error('Registro no válido');last=e[0];}
 let i=0;for(let t=0;t<=steps;t++){while(i<events.length&&events[i][0]===t){let ok=events[i][1]==='s'?g.switch():g.revive();if(!ok)throw Error('Movimiento imposible');i++;}if(t===steps)break;if(g.dead)throw Error('La partida ya había terminado');g.tick();}
 if(!g.dead||g.score<100)throw Error('La ronda debe terminar con al menos 100 puntos');
 return {score:g.score,seconds:g.seconds,revived:g.revived};
}
const api={Round,verify,HZ,RULES};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.OrbitaRules=api;
})(typeof window!=='undefined'?window:globalThis);
