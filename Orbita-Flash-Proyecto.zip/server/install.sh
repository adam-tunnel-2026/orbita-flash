#!/bin/sh
set -eu
# Independent service. Does not modify VPNs, reverse proxies, tunnels or firewalls.
command -v node >/dev/null || { echo 'Falta Node.js. Instala Node.js 18 o posterior antes de continuar.'; exit 1; }
node -e 'if(Number(process.versions.node.split(".")[0])<18)process.exit(1)' || { echo 'Se necesita Node.js 18 o posterior'; exit 1; }
if [ "$(id -u)" != 0 ]; then echo 'Ejecuta con sudo'; exit 1; fi
if ! systemctl is-active --quiet orbita-community; then
 node -e 'const s=require("net").createServer();s.once("error",()=>process.exit(1));s.listen(8788,"127.0.0.1",()=>s.close())' || { echo 'Puerto 8788 ocupado. No se ha cambiado nada.'; exit 1; }
fi
mkdir -p /opt/orbita-community
for name in server.js game-core.js verify-worker.js; do install -m 644 "$(dirname "$0")/$name" "/opt/orbita-community/$name"; done
ORBITA_NODE=$(command -v node)
cat > /etc/systemd/system/orbita-community.service <<UNIT
[Unit]
Description=Marcador de pueblos de Orbita Flash
After=network-online.target
Wants=network-online.target
[Service]
DynamicUser=yes
StateDirectory=orbita-community
Environment=DATA_DIR=/var/lib/orbita-community
Environment=PORT=8788
WorkingDirectory=/opt/orbita-community
ExecStart=$ORBITA_NODE /opt/orbita-community/server.js
Restart=on-failure
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now orbita-community
systemctl restart orbita-community
printf 'Servicio instalado en 127.0.0.1:8788. Falta conectar una URL HTTPS propia de Órbita Flash.\n'
