'use strict';
const HOUR=3600000,MIN_SCORE=100,MODE='hourly-v1';
const hourStart=n=>Math.floor(n/HOUR)*HOUR;
const cityKey=s=>s.normalize('NFD').replace(/\p{M}/gu,'').toLocaleLowerCase('es').replace(/[ .’'\-]/gu,'');
function rank(rows,start){const best=new Map();for(const r of rows){if(r.roundStart!==start||!r.city||!Number.isInteger(r.score))continue;const k=cityKey(r.city),old=best.get(k);if(!old||r.score>old.score||(r.score===old.score&&r.createdAt<old.createdAt))best.set(k,r)}return [...best.values()].sort((a,b)=>b.score-a.score||a.createdAt-b.createdAt||a.city.localeCompare(b.city,'es')).map(({city,score,createdAt,expiresAt})=>({city,score,createdAt,expiresAt}));}
module.exports={HOUR,MIN_SCORE,MODE,hourStart,cityKey,rank};
