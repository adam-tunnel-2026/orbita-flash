#!/usr/bin/env python3
import json,sys
from pathlib import Path
from urllib.parse import urlsplit
if len(sys.argv)!=2:raise SystemExit('Uso: python3 server/configure-community.py https://tu-subdominio')
u=urlsplit(sys.argv[1])
if u.scheme!='https' or not u.hostname or u.username or u.password or u.path not in ('','/') or u.query or u.fragment:raise SystemExit('Introduce solo una URL HTTPS, sin rutas ni credenciales')
p=Path(__file__).resolve().parents[1]/'app/src/main/assets/community-config.json'
p.write_text(json.dumps({'url':sys.argv[1].rstrip('/')},ensure_ascii=False)+'\n')
print('URL guardada. Vuelve a comprimir el proyecto y compilar la APK.')
