#!/usr/bin/env bash
# Runs only on a dedicated test device/emulator. Does not erase or uninstall an app.
set -euo pipefail
app=es.orbitaflash.game
before=orbita-update-test-before.apk
after=orbita-update-test-after.apk
# Do not overwrite an unexpected pre-existing app on a user's device.
if adb shell pm path "$app" | tr -d '\r' | grep -q '^package:'; then
  echo 'La prueba requiere un emulador limpio sin Orbita Flash instalada.'
  exit 1
fi
adb install "$before"
adb shell am start -W -n "$app/.MainActivity"
for attempt in $(seq 1 5); do
  sleep 1
  adb shell pidof "$app" >/dev/null || { echo 'La primera version se ha cerrado.'; exit 1; }
done
adb shell am force-stop "$app"
printf 'orbita-permanent-signature-proof-v1' | adb shell run-as "$app" sh -c '"mkdir -p files; cat > files/update-proof.txt"'
first_uid=$(adb shell run-as "$app" id -u | tr -d '\r')
test -n "$first_uid"
adb install -r "$after"
second_uid=$(adb shell run-as "$app" id -u | tr -d '\r')
test "$first_uid" = "$second_uid"
proof=$(adb shell run-as "$app" cat files/update-proof.txt | tr -d '\r')
test "$proof" = 'orbita-permanent-signature-proof-v1'
adb shell am start -W -n "$app/.MainActivity"
for attempt in $(seq 1 5); do
  sleep 1
  adb shell pidof "$app" >/dev/null || { echo 'La version actualizada se ha cerrado.'; exit 1; }
done
echo 'PASS: dos versiones con firma permanente, instalacion -r sin desinstalar, mismo UID, archivo privado conservado y juego abierto.'
echo 'Esta prueba no migra las firmas antiguas ni comprueba el flujo visual de descarga del actualizador.'
