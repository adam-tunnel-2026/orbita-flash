#!/usr/bin/env python3
"""Restore the one persistent CI signing identity; never create or log a key."""
import base64
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys

def prepare():
    source = os.environ.get('ORBITA_SIGNING_BUNDLE', '')
    if not source:
        raise ValueError('Falta el secreto ORBITA_SIGNING_BUNDLE. No se generará otra firma.')
    try:
        data = json.loads(source)
    except (TypeError, json.JSONDecodeError):
        raise ValueError('ORBITA_SIGNING_BUNDLE debe contener el archivo privado completo.') from None
    if data.get('format') != 1:
        raise ValueError('Formato de firma desconocido.')
    expected = pathlib.Path('signing-certificate.sha256').read_text().strip().lower()
    if not re.fullmatch('[a-f0-9]{64}', expected) or data.get('certificateSha256') != expected:
        raise ValueError('La firma no coincide con la identidad permanente fijada en el proyecto.')
    if not re.fullmatch('[A-Za-z0-9_-]{1,80}', data.get('alias', '')):
        raise ValueError('Alias de firma no válido.')
    for field in ('storePassword', 'keyPassword'):
        value = data.get(field)
        if not isinstance(value, str) or not 8 <= len(value) <= 200 or '\n' in value or '\r' in value:
            raise ValueError('Datos de firma incompletos.')
    raw = base64.b64decode(data['keystore'], validate=True)
    if not 100 <= len(raw) <= 32768:
        raise ValueError('Tamaño de clave no permitido.')
    destination = pathlib.Path(os.environ['RUNNER_TEMP']) / 'orbita-signing.p12'
    destination.write_bytes(raw)
    destination.chmod(0o600)
    env = dict(os.environ, ORBITA_STORE_PASSWORD=data['storePassword'], ORBITA_KEY_PASSWORD=data['keyPassword'])
    result = subprocess.run(['keytool', '-exportcert', '-keystore', str(destination), '-alias', data['alias'],
                             '-storepass:env', 'ORBITA_STORE_PASSWORD'], env=env, capture_output=True)
    if result.returncode or hashlib.sha256(result.stdout).hexdigest() != expected:
        destination.unlink(missing_ok=True)
        raise ValueError('No se puede abrir la clave o su certificado no coincide.')
    # Mask individual components as well as the enclosing GitHub Secret.
    for value in (data['storePassword'], data['keyPassword'], data['keystore']):
        print('::add-mask::' + value)
    with open(os.environ['GITHUB_ENV'], 'a') as out:
        for name, value in {'ORBITA_SIGNING_STORE': str(destination), 'ORBITA_STORE_PASSWORD': data['storePassword'],
                            'ORBITA_KEY_PASSWORD': data['keyPassword'], 'ORBITA_KEY_ALIAS': data['alias'],
                            'ORBITA_CERT_SHA256': expected}.items():
            out.write(name + '=' + value + '\n')
    print('Identidad permanente verificada. Se reutilizará sin generar otra clave.')

if __name__ == '__main__':
    try:
        prepare()
    except Exception as error:
        # Do not stringify parser exceptions that might contain the supplied secret.
        message = str(error) if isinstance(error, ValueError) and not isinstance(error, json.JSONDecodeError) else 'No se pudo preparar la firma permanente.'
        print(message, file=sys.stderr)
        sys.exit(1)
