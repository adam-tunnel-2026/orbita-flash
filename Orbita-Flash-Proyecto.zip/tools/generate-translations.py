from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET,re
root=Path(__file__).resolve().parents[1]; catalog={}
for n,line in enumerate((root/'i18n/catalog.tsv').read_text().splitlines(),1):
 if not line:continue
 values=line.split('\t');assert len(values)==4,(n,len(values),line)
 values=[v.replace('\\n','\n') for v in values]
 key=values[0];assert key not in catalog,('duplicate',key)
 catalog[key]=dict(zip(('es','en','eu','fr'),values))
key='No se pudo abrir el juego. Vuelve a instalar la APK.'
catalog[key]['es']='No se pudo abrir el juego. Actualiza la APK sin desinstalar.'
(root/'i18n/catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
# Native Android resources. Explicit quotes preserve spaces in sentence fragments.
for language,folder in [('es','values'),('en','values-en'),('eu','values-eu'),('fr','values-fr')]:
 strings=ET.Element('resources')
 for source,row in catalog.items():
  name='tr_'+hashlib.sha256(source.encode()).hexdigest()[:12]
  element=ET.SubElement(strings,'string',name=name,formatted='false')
  value=row[language].replace('\\','\\\\').replace('\n','\\n').replace("'","\\'").replace('"','\\"')
  element.text='"'+value+'"'
 ET.indent(strings)
 path=root/'app/src/main/res'/folder/'strings.xml';path.parent.mkdir(parents=True,exist_ok=True)
 ET.ElementTree(strings).write(path,encoding='utf-8',xml_declaration=True)
lines=['package es.orbitaflash.game;','import android.content.Context;','import android.os.LocaleList;','import java.util.Locale;','final class L10n {',
 ' static String language(Context c) {','  LocaleList list=c.getResources().getConfiguration().getLocales();',
 '  for(int i=0;i<list.size();i++){String code=list.get(i).getLanguage();if(code.equals("es")||code.equals("eu")||code.equals("en")||code.equals("fr"))return code;}','  return "es";',' }',
 ' static String text(Context c,String source){','  switch(source){']
for source in catalog:
 name='tr_'+hashlib.sha256(source.encode()).hexdigest()[:12]
 lines.append('   case '+json.dumps(source,ensure_ascii=False)+': return c.getString(R.string.'+name+');')
lines+=['   default: return source;','  }',' }',' private L10n(){}','}']
(root/'app/src/main/java/es/orbitaflash/game/L10n.java').write_text('\n'.join(lines)+'\n')

# Refresh the inline catalog used by the local WebView without changing game data.
p=root/'app/src/main/assets/index.html'
s=p.read_text()
inline=json.dumps(catalog,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
s,count=re.subn(r'const TRANSLATIONS=.*?;\nfunction chooseLanguage',lambda m:'const TRANSLATIONS='+inline+';\nfunction chooseLanguage',s,count=1)
assert count==1,'Missing inline translation catalog'
p.write_text(s)
print('Generated',len(catalog),'messages in four languages')
