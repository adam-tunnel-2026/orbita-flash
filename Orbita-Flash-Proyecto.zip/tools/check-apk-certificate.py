import pathlib,re,sys
expected=pathlib.Path('signing-certificate.sha256').read_text().strip().lower()
text=pathlib.Path(sys.argv[1]).read_text()
match=re.search(r'Signer #1 certificate SHA-256 digest: ([0-9a-fA-F]+)',text)
if not match or match[1].lower()!=expected:
 raise SystemExit('La APK no tiene la firma permanente fijada. No se distribuye.')
print('APK verificada con la firma permanente correcta.')
