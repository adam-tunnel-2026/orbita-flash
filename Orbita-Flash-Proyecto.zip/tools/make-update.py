#!/usr/bin/env python3
"""Create release metadata from the APK itself, never guessed sizes/hashes."""
import argparse
import hashlib
import json
import pathlib
import re
import subprocess

def make(apk, tag, aapt):
    info = subprocess.check_output([str(aapt), "dump", "badging", str(apk)], text=True)
    package = re.search(r"package: name='([^']+)' versionCode='(\d+)' versionName='([^']+)'", info)
    sdk = re.search(r"sdkVersion:'(\d+)'", info)
    if not package or not sdk or package[1] != "es.orbitaflash.game":
        raise ValueError("La APK no pertenece a Órbita Flash")
    if not re.fullmatch(r"v\d+\.\d+\.\d+", tag) or tag != "v" + package[3]:
        raise ValueError("La etiqueta no coincide con la versión de la APK")
    content = apk.read_bytes()
    if not 0 < len(content) <= 256 * 1024 * 1024:
        raise ValueError("Tamaño de APK no permitido")
    return dict(packageName=package[1], versionCode=int(package[2]), versionName=package[3], minSdk=int(sdk[1]),
                url=f"https://github.com/adam-tunnel-2026/orbita-flash/releases/download/{tag}/Orbita-Flash.apk",
                sha256=hashlib.sha256(content).hexdigest(), size=len(content))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("apk", type=pathlib.Path)
    parser.add_argument("tag")
    parser.add_argument("--aapt", required=True, type=pathlib.Path)
    parser.add_argument("--out", type=pathlib.Path, default=pathlib.Path("update.json"))
    args = parser.parse_args()
    args.out.write_text(json.dumps(make(args.apk, args.tag, args.aapt), ensure_ascii=False, indent=2) + "\n")
