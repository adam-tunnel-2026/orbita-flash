'use strict';
// Runs the actual inline client with a minimal DOM; no browser dependencies.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
function client(reduced=false){
 const nodes=new Map(),noop=()=>{};
 function element(){return {style:{},dataset:{},children:[],attributes:{},textContent:'',hidden:false,open:false,disabled:false,clientWidth:360,clientHeight:340,value:'',classList:{add:noop,remove:noop},append(...children){this.children.push(...children)},replaceChildren(){this.children=[]},contains(){return false},setAttribute(k,v){this.attributes[k]=v},addEventListener:noop,getContext(){return {}},showModal(){this.open=true},close(){this.open=false}}}
 const get=id=>{if(!nodes.has(id))nodes.set(id,element());return nodes.get(id)};
 const document={documentElement:{},hidden:false,activeElement:{tagName:'BODY'},getElementById:get,createElement:element,createElementNS:()=>element(),addEventListener:noop,querySelectorAll:()=>[]};
 get('hourHistory').open=true;
 const sandbox={Math,Date,JSON,URL,console,setTimeout:()=>1,clearTimeout:noop,setInterval:noop,requestAnimationFrame:noop,navigator:{languages:['es-ES']},document,matchMedia:()=>({matches:reduced,addEventListener:noop}),localStorage:{getItem:()=>null,setItem:noop}};
 sandbox.window=sandbox;
 const context=vm.createContext(sandbox);
 for(const script of html.matchAll(/<script>([\s\S]*?)<\/script>/g))vm.runInContext(script[1],context);
 const run=s=>vm.runInContext(s,context);
 function load(count=24,places=3){run(`clockOffset=0;fullHistory=true;hourlyPodiums=Array.from({length:${count}},(_,i)=>({roundStart:Math.floor(Date.now()/HOUR)*HOUR-(i+1)*HOUR,roundEnd:Math.floor(Date.now()/HOUR)*HOUR-i*HOUR,towns:Array.from({length:${places}},(_,rank)=>({city:'Pueblo '+i+' '+rank,score:200-rank}))}));renderHourlyPodiums()`)}
 return {get,document,run,load};
}
const b=client();b.load();
assert.equal(b.get('podiumStage').children.length,8,'bounded DOM for 72 results');
assert.equal(b.get('podiumPosition').textContent,'1 de 72 · Pueblo 0 0');
assert(b.get('previousPodium').textContent.includes('3. Pueblo 23 2'));
b.run('podiumCarousel.frame(1000);for(let t=1050;t<=4950;t+=50)podiumCarousel.frame(t)');
const moving=b.get('podiumStage').children.map(n=>n.children[0].attributes.d);
assert.equal(b.get('podiumStage').children.filter(n=>n.dataset.front==='true').length,1,'one centred readable label during dwell');
assert(b.get('podiumStage').children.every(n=>n.style.opacity==='1'),'all surfaces stay opaque');
assert(b.get('podiumStage').children.some(n=>n.dataset.rear==='true'),'rear faces classified separately');
b.run('for(let t=5000;t<=5300;t+=50)podiumCarousel.frame(t)');
assert.notDeepEqual(b.get('podiumStage').children.map(n=>n.children[0].attributes.d),moving,'rotation runs');
b.get('podiumRotation').onclick();
const frozen=b.get('podiumStage').children.map(n=>n.children[0].attributes.d);
b.run('podiumCarousel.frame(5350);podiumCarousel.frame(5400)');
assert.deepEqual(b.get('podiumStage').children.map(n=>n.children[0].attributes.d),frozen,'pause freezes');
assert.equal(b.get('podiumStage').children.filter(n=>n.dataset.front==='true').length,1,'pause snaps to centre');
b.get('podiumBack').onclick();assert.equal(b.get('podiumPosition').textContent,'72 de 72 · Pueblo 23 2');
b.get('podiumNext').onclick();assert.equal(b.get('podiumPosition').textContent,'1 de 72 · Pueblo 0 0');
// Swipe forward and backward; scrolling vertically must not change the result.
b.get('podiumStage').onpointerdown({clientX:200,clientY:100});b.get('podiumStage').onpointerup({clientX:80,clientY:100});
assert.equal(b.get('podiumPosition').textContent,'2 de 72 · Pueblo 0 1');
b.get('podiumStage').onpointerdown({clientX:100,clientY:100});b.get('podiumStage').onpointerup({clientX:101,clientY:200});
assert.equal(b.get('podiumPosition').textContent,'2 de 72 · Pueblo 0 1');
// Periodic render of unchanged results must not reset the selected town.
b.run('renderHourlyPodiums()');assert.equal(b.get('podiumPosition').textContent,'2 de 72 · Pueblo 0 1');
b.get('podiumList').open=true;b.run('renderHourlyPodiums()');assert(b.get('podiumList').open,'periodic refresh preserves full-list expansion');
// Unsafe names stay text, never HTML; long labels remain in the full list.
b.run(`hourlyPodiums[0].towns[1].city='<img src=x onerror=alert(1)>';renderHourlyPodiums()`);
assert(b.get('podiumStage').children.some(n=>n.children[1].textContent.includes('<img')));
assert(b.get('podiumStage').children.every(n=>!Object.hasOwn(n,'innerHTML')));
// Offline expiry clears the visual ring and full list immediately.
b.run('clockOffset=26*HOUR;renderHourlyPodiums()');
assert.equal(b.get('podiumCarousel').hidden,true);assert.equal(b.get('podiumStage').children.length,0);
assert(!b.get('previousPodium').textContent.includes('Pueblo'));
b.load(1,1);assert.equal(b.get('podiumStage').children.length,8);assert(b.get('podiumRotation').disabled);
b.load(2,3);assert.equal(b.get('podiumStage').children.length,8);
b.get('podiumNext').onclick();
const held=b.get('podiumStage').children.map(n=>n.children[0].attributes.d);
b.get('podiumRotation').onclick();b.document.hidden=true;b.run('podiumCarousel.frame(5000);podiumCarousel.frame(5050)');
assert.deepEqual(b.get('podiumStage').children.map(n=>n.children[0].attributes.d),held,'background does not rotate');
b.document.hidden=false;b.get('hourHistory').open=false;b.run('podiumCarousel.frame(5100)');
assert.deepEqual(b.get('podiumStage').children.map(n=>n.children[0].attributes.d),held,'collapsed history does not rotate');
// The same physical ring geometry is used for every screen width and export.
for(const width of [264,296,320,360,420]){
 const sized=client();sized.get('podiumStage').clientWidth=width;sized.load(2,3);
 const surfaces=sized.get('podiumStage').children;
 assert.equal(surfaces.filter(n=>n.dataset.rear==='true').length,5,'five rear surfaces');
 assert.equal(surfaces.filter(n=>n.dataset.front==='false'&&n.dataset.rear==='false').length,2,'two side names');
 for(let relative=-4;relative<=5;relative+=.02){
  const bounds=sized.run('podiumRingGeometry('+relative+').bounds');
  assert(bounds.left>=24&&bounds.right<=616,'curved outlines stay inside viewBox');
  assert(bounds.top>=5&&bounds.bottom<=143,'front and rear arcs stay inside viewBox');
 }
 for(const city of ['Salamanca','Gipuzkoa','Azpeitia']){
  assert.equal(sized.run('podiumRingDrawing({city:'+JSON.stringify(city)+'},-1).title'),city,'common side names remain complete');
  assert.equal(sized.run('podiumRingDrawing({city:'+JSON.stringify(city)+'},1).title'),city);
 }
 // Curves are real SVG outlines; the text never receives a transform.
 for(const node of surfaces){
  assert(node.children[0].attributes.d.includes(' Q '),'rounded curved outline');
  assert.equal(node.children[1].attributes.transform,undefined,'letters keep normal proportions');
 }
}
const accessible=client(true);accessible.load(2,3);
assert.equal(accessible.get('podiumRotation').attributes['aria-pressed'],'true','reduced motion starts paused');
console.log('PASS carousel: 72 results / 8 surfaces, all top-3 ranks, uncompressed side names, five rear panels, shared SVG curves, complete common side names, 264–420px bounds, centred dwell, opaque faces, hidden rear text, rotation, pause, wrap, swipes, vertical scroll, stable refresh, text-safe names, offline expiry, empty/single/small rings, hidden and collapsed pause, reduced motion');
