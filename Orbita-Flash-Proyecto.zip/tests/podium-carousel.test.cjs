'use strict';
// Runs the actual inline client with a minimal DOM; no browser dependencies.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
function client(reduced=false){
 const nodes=new Map(),noop=()=>{};
 function element(){return {style:{},dataset:{},children:[],attributes:{},textContent:'',hidden:false,open:false,disabled:false,clientWidth:360,clientHeight:340,value:'',classList:{add:noop,remove:noop},append(...children){this.children.push(...children)},replaceChildren(){this.children=[]},contains(){return false},setAttribute(k,v){this.attributes[k]=v},addEventListener:noop,getContext(){return {}},showModal(){this.open=true},close(){this.open=false}}}
 const get=id=>{if(!nodes.has(id))nodes.set(id,element());return nodes.get(id)};
 const document={documentElement:{},hidden:false,activeElement:{tagName:'BODY'},getElementById:get,createElement:element,addEventListener:noop,querySelectorAll:()=>[]};
 get('hourHistory').open=true;
 const sandbox={Math,Date,JSON,URL,console,setTimeout:()=>1,clearTimeout:noop,setInterval:noop,requestAnimationFrame:noop,navigator:{languages:['es-ES']},document,matchMedia:()=>({matches:reduced,addEventListener:noop}),localStorage:{getItem:()=>null,setItem:noop}};
 sandbox.window=sandbox;
 const context=vm.createContext(sandbox);
 for(const script of html.matchAll(/<script>([\s\S]*?)<\/script>/g))vm.runInContext(script[1],context);
 const run=s=>vm.runInContext(s,context);
 function load(count=24,places=3){run(`clockOffset=0;fullHistory=true;hourlyPodiums=Array.from({length:${count}},(_,i)=>({roundStart:Math.floor(Date.now()/HOUR)*HOUR-(i+1)*HOUR,roundEnd:Math.floor(Date.now()/HOUR)*HOUR-i*HOUR,towns:Array.from({length:${places}},(_,rank)=>({city:'Pueblo '+i+' '+rank,score:200-rank}))}));renderHourlyPodiums()`)}
 return {get,document,run,load};
}
const b=client();b.load();
assert.equal(b.get('podiumStage').children.length,7,'bounded DOM for 72 results');
assert.equal(b.get('podiumPosition').textContent,'1 de 72 · Pueblo 0 0');
assert(b.get('previousPodium').textContent.includes('3. Pueblo 23 2'));
b.run('podiumCarousel.frame(1000);podiumCarousel.frame(1050)');
const moving=b.get('podiumStage').children.map(n=>n.style.transform);
b.run('podiumCarousel.frame(1100)');
assert.notDeepEqual(b.get('podiumStage').children.map(n=>n.style.transform),moving,'rotation runs');
b.get('podiumRotation').onclick();
const frozen=b.get('podiumStage').children.map(n=>n.style.transform);
b.run('podiumCarousel.frame(1150);podiumCarousel.frame(1200)');
assert.deepEqual(b.get('podiumStage').children.map(n=>n.style.transform),frozen,'pause freezes');
b.get('podiumBack').onclick();assert.equal(b.get('podiumPosition').textContent,'72 de 72 · Pueblo 23 2');
b.get('podiumNext').onclick();assert.equal(b.get('podiumPosition').textContent,'1 de 72 · Pueblo 0 0');
// Swipe forward and backward; scrolling vertically must not change the result.
b.get('podiumStage').onpointerdown({clientX:200,clientY:100});b.get('podiumStage').onpointerup({clientX:80,clientY:100});
assert.equal(b.get('podiumPosition').textContent,'2 de 72 · Pueblo 0 1');
b.get('podiumStage').onpointerdown({clientX:100,clientY:100});b.get('podiumStage').onpointerup({clientX:101,clientY:200});
assert.equal(b.get('podiumPosition').textContent,'2 de 72 · Pueblo 0 1');
// Periodic render of unchanged results must not reset the selected town.
b.run('renderHourlyPodiums()');assert.equal(b.get('podiumPosition').textContent,'2 de 72 · Pueblo 0 1');
b.get('podiumList').open=true;b.run('renderHourlyPodiums()');assert(b.get('podiumList').open,'periodic refresh preserves full-list expansion');
// Unsafe names stay text, never HTML; long labels remain in the full list.
b.run(`hourlyPodiums[0].towns[1].city='<img src=x onerror=alert(1)>';renderHourlyPodiums()`);
assert(b.get('podiumStage').children.some(n=>n.children[0].textContent.includes('<img')));
assert(b.get('podiumStage').children.every(n=>!Object.hasOwn(n,'innerHTML')));
// Offline expiry clears the visual ring and full list immediately.
b.run('clockOffset=26*HOUR;renderHourlyPodiums()');
assert.equal(b.get('podiumCarousel').hidden,true);assert.equal(b.get('podiumStage').children.length,0);
assert(!b.get('previousPodium').textContent.includes('Pueblo'));
b.load(1,1);assert.equal(b.get('podiumStage').children.length,1);assert(b.get('podiumRotation').disabled);
b.load(2,3);assert.equal(b.get('podiumStage').children.length,6);
b.get('podiumNext').onclick();
const held=b.get('podiumStage').children.map(n=>n.style.transform);
b.get('podiumRotation').onclick();b.document.hidden=true;b.run('podiumCarousel.frame(5000);podiumCarousel.frame(5050)');
assert.deepEqual(b.get('podiumStage').children.map(n=>n.style.transform),held,'background does not rotate');
b.document.hidden=false;b.get('hourHistory').open=false;b.run('podiumCarousel.frame(5100)');
assert.deepEqual(b.get('podiumStage').children.map(n=>n.style.transform),held,'collapsed history does not rotate');
const accessible=client(true);accessible.load(2,3);
assert.equal(accessible.get('podiumRotation').attributes['aria-pressed'],'true','reduced motion starts paused');
console.log('PASS carousel: 72 results / 7 labels, all top-3 ranks, rotation, pause, wrap, swipes, vertical scroll, stable refresh, text-safe names, offline expiry, empty/single/small rings, hidden and collapsed pause, reduced motion');
