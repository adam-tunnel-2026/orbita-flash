'use strict';
// Runs the actual inline client with a minimal DOM; no browser dependencies.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
function client(reduced=false){
 const nodes=new Map(),noop=()=>{};
 function element(){return {style:{},dataset:{},children:[],attributes:{},textContent:'',hidden:false,open:false,disabled:false,clientWidth:360,clientHeight:340,value:'',classList:{add:noop,remove:noop},append(...children){this.children.push(...children)},replaceChildren(){this.children=[]},contains(){return false},setAttribute(k,v){this.attributes[k]=v},addEventListener:noop,getContext(){return {}},showModal(){this.open=true},close(){this.open=false}}}
 const get=id=>{if(!nodes.has(id))nodes.set(id,element());return nodes.get(id)};
 const document={documentElement:{},hidden:false,activeElement:{tagName:'BODY'},getElementById:get,createElement:element,addEventListener:noop,querySelectorAll:()=>[]};
 get('hourHistory').open=true;
 const sandbox={Math,Date,JSON,URL,console,setTimeout:()=>1,clearTimeout:noop,setInterval:noop,requestAnimationFrame:noop,navigator:{languages:['es-ES']},document,matchMedia:()=>({matches:reduced,addEventListener:noop}),localStorage:{getItem:()=>null,setItem:noop}};
 sandbox.window=sandbox;
 const context=vm.createContext(sandbox);
 for(const script of html.matchAll(/<script>([\s\S]*?)<\/script>/g))vm.runInContext(script[1],context);
 const run=s=>vm.runInContext(s,context);
 function load(count=24,places=3){run(`clockOffset=0;fullHistory=true;hourlyPodiums=Array.from({length:${count}},(_,i)=>({roundStart:Math.floor(Date.now()/HOUR)*HOUR-(i+1)*HOUR,roundEnd:Math.floor(Date.now()/HOUR)*HOUR-i*HOUR,towns:Array.from({length:${places}},(_,rank)=>({city:'Pueblo '+i+' '+rank,score:200-rank}))}));renderHourlyPodiums()`)}
 return {get,document,run,load};
}
const b=client();b.load();
assert.equal(b.get('podiumStage').children.length,8,'bounded DOM for 72 results');
assert.equal(b.get('podiumPosition').textContent,'1 de 72 · Pueblo 0 0');
assert(b.get('previousPodium').textContent.includes('3. Pueblo 23 2'));
b.run('podiumCarousel.frame(1000);for(let t=1050;t<=4950;t+=50)podiumCarousel.frame(t)');
const moving=b.get('podiumStage').children.map(n=>n.style.transform);
assert.equal(b.get('podiumStage').children.filter(n=>n.dataset.front==='true').length,1,'one centred readable label during dwell');
assert(b.get('podiumStage').children.every(n=>n.style.opacity==='1'),'all surfaces stay opaque');
assert(b.get('podiumStage').children.some(n=>n.dataset.rear==='true'),'rear faces classified separately');
b.run('for(let t=5000;t<=5300;t+=50)podiumCarousel.frame(t)');
assert.notDeepEqual(b.get('podiumStage').children.map(n=>n.style.transform),moving,'rotation runs');
b.get('podiumRotation').onclick();
const frozen=b.get('podiumStage').children.map(n=>n.style.transform);
b.run('podiumCarousel.frame(5350);podiumCarousel.frame(5400)');
assert.deepEqual(b.get('podiumStage').children.map(n=>n.style.transform),frozen,'pause freezes');
assert.equal(b.get('podiumStage').children.filter(n=>n.dataset.front==='true').length,1,'pause snaps to centre');
b.get('podiumBack').onclick();assert.equal(b.get('podiumPosition').textContent,'72 de 72 · Pueblo 23 2');
b.get('podiumNext').onclick();assert.equal(b.get('podiumPosition').textContent,'1 de 72 · Pueblo 0 0');
// Swipe forward and backward; scrolling vertically must not change the result.
b.get('podiumStage').onpointerdown({clientX:200,clientY:100});b.get('podiumStage').onpointerup({clientX:80,clientY:100});
assert.equal(b.get('podiumPosition').textContent,'2 de 72 · Pueblo 0 1');
b.get('podiumStage').onpointerdown({clientX:100,clientY:100});b.get('podiumStage').onpointerup({clientX:101,clientY:200});
assert.equal(b.get('podiumPosition').textContent,'2 de 72 · Pueblo 0 1');
// Periodic render of unchanged results must not reset the selected town.
b.run('renderHourlyPodiums()');assert.equal(b.get('podiumPosition').textContent,'2 de 72 · Pueblo 0 1');
b.get('podiumList').open=true;b.run('renderHourlyPodiums()');assert(b.get('podiumList').open,'periodic refresh preserves full-list expansion');
// Unsafe names stay text, never HTML; long labels remain in the full list.
b.run(`hourlyPodiums[0].towns[1].city='<img src=x onerror=alert(1)>';renderHourlyPodiums()`);
assert(b.get('podiumStage').children.some(n=>n.children[0].textContent.includes('<img')));
assert(b.get('podiumStage').children.every(n=>!Object.hasOwn(n,'innerHTML')));
// Offline expiry clears the visual ring and full list immediately.
b.run('clockOffset=26*HOUR;renderHourlyPodiums()');
assert.equal(b.get('podiumCarousel').hidden,true);assert.equal(b.get('podiumStage').children.length,0);
assert(!b.get('previousPodium').textContent.includes('Pueblo'));
b.load(1,1);assert.equal(b.get('podiumStage').children.length,8);assert(b.get('podiumRotation').disabled);
b.load(2,3);assert.equal(b.get('podiumStage').children.length,8);
b.get('podiumNext').onclick();
const held=b.get('podiumStage').children.map(n=>n.style.transform);
b.get('podiumRotation').onclick();b.document.hidden=true;b.run('podiumCarousel.frame(5000);podiumCarousel.frame(5050)');
assert.deepEqual(b.get('podiumStage').children.map(n=>n.style.transform),held,'background does not rotate');
b.document.hidden=false;b.get('hourHistory').open=false;b.run('podiumCarousel.frame(5100)');
assert.deepEqual(b.get('podiumStage').children.map(n=>n.style.transform),held,'collapsed history does not rotate');
// Check rotated card corners, not just centre points, across the entire turn.
// This catches the clipped side labels seen in the Android screenshot.
for(const width of [264,296,320,360,420]){
 const sized=client();sized.get('podiumStage').clientWidth=width;sized.load(2,3);
 const surfaces=sized.get('podiumStage').children;
 assert.equal(surfaces.filter(n=>n.dataset.rear==='true').length,5,'five visible rear surfaces even with six results');
 assert.equal(surfaces.filter(n=>n.dataset.front==='false'&&n.dataset.rear==='false').length,2,'two readable side labels');
 for(let time=1000;time<=12500;time+=50){
  sized.run('podiumCarousel.frame('+time+')');
  for(const node of surfaces){
   assert(!/scale|rotateY/.test(node.style.transform),'text is never squeezed by perspective');
   const match=/translate\(([-.0-9]+)px,([-.0-9]+)px\) rotate\(([-.0-9]+)deg\)/.exec(node.style.transform);
   assert(match,'explicit screen projection');
   const x=Number(match[1]),y=Number(match[2]),angle=Number(match[3])*Math.PI/180;
   const w=parseFloat(node.style.width),h=parseFloat(node.style.height);
   const halfX=w/2*Math.abs(Math.cos(angle))+h/2*Math.abs(Math.sin(angle));
   const halfY=w/2*Math.abs(Math.sin(angle))+h/2*Math.abs(Math.cos(angle));
   assert(x+w/2-halfX>=-.1&&x+w/2+halfX<=width+.1,'panel corners stay within stage at '+width+'px');
   assert(y+h/2-halfY>=0&&y+h/2+halfY<=104,'rear and front arcs stay inside stage');
  }
 }
}
const accessible=client(true);accessible.load(2,3);
assert.equal(accessible.get('podiumRotation').attributes['aria-pressed'],'true','reduced motion starts paused');
console.log('PASS carousel: 72 results / 8 surfaces, all top-3 ranks, uncompressed side names, five rear panels, 264–420px rotating bounds, centred dwell, opaque faces, hidden rear text, rotation, pause, wrap, swipes, vertical scroll, stable refresh, text-safe names, offline expiry, empty/single/small rings, hidden and collapsed pause, reduced motion');
