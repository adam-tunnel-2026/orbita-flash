'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto'),vm=require('node:vm');
const {Round,verify,HZ,RULES}=require('../server/game-core.js');
const {HOUR,MIN_SCORE,MODE,rank}=require('../server/competition.js');
function makeRun(seed=123,target=40){const g=new Round(seed);while(g.seconds<target&&!g.dead){const o=g.obstacles.find(o=>o.a-g.angle>0&&o.a-g.angle<.65);if(o&&o.l===g.lane)g.switch();g.tick()}while(!g.dead&&g.seconds<120)g.tick();assert(g.dead);return g}
async function main(){
const run=makeRun(),short=Array.from({length:50},(_,i)=>makeRun(i,20)).find(r=>r.score>=100&&r.score<150);assert(short,'a real 100–149-point round');assert.equal(verify(short.seed,short.events,short.steps).score,short.score);assert.throws(()=>verify(1,[],2399));
assert.equal(verify(run.seed,run.events,run.steps).score,run.score);const revivedRun=makeRun(222);assert(revivedRun.revive());while(!revivedRun.dead&&revivedRun.seconds<180)revivedRun.tick();assert(verify(revivedRun.seed,revivedRun.events,revivedRun.steps).revived);assert.throws(()=>verify(run.seed,[],run.steps));assert.throws(()=>verify(run.seed,run.events,run.steps+1));assert.throws(()=>verify(run.seed,[[1,'r']],run.steps));
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'orbita-test-'));process.env.DATA_DIR=tmp;const realNow=Date.now,base=Math.floor(realNow()/HOUR)*HOUR;let now=base+600000;Date.now=()=>now;
let mod=require('../server/server.js');const {normalizeCity,cityKey}=mod;assert.equal(normalizeCity('  San   Sebastián '),'San Sebastián');assert.equal(cityKey('Azpeitia.'),cityKey('azpeitia'));for(const bad of ['<script>','a','Gilípollas','A'.repeat(41),'https://evil.com'])assert.throws(()=>normalizeCity(bad));assert.equal(normalizeCity("L'Hospitalet de Llobregat"),"L'Hospitalet de Llobregat");
await new Promise(resolve=>mod.server.listen(0,'127.0.0.1',resolve));let url='http://127.0.0.1:'+mod.server.address().port;const key=fs.readFileSync(path.join(tmp,'secret'));
function token(id,seed){let b=Buffer.from(JSON.stringify({id,seed,time:Date.now()-300000,rules:RULES})).toString('base64url');return b+'.'+crypto.createHmac('sha256',key).update(b).digest('base64url')}
async function req(p,body){let r=await fetch(url+p,body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{});return {status:r.status,data:await r.json()}}
const pub=(id,city,g=run)=>({token:token(id,g.seed),city,events:g.events,steps:g.steps,score:9999999});
try{
assert.equal((await req('/health')).data.competition,MODE);assert.equal((await req('/health')).data.minScore,100);assert.equal((await req('/rounds',{rules:RULES})).status,200);assert.equal((await req('/rounds',{rules:'orbita-v05'})).status,400);
const publish=pub('one','Azpeitia');let result=await req('/towns',publish);assert.equal(result.status,200);assert.equal(result.data.score,run.score);assert.equal(result.data.expiresAt,base+HOUR);now+=1000;assert.equal((await req('/towns',publish)).data.expiresAt,base+HOUR);
assert.equal((await req('/towns',{...publish,token:publish.token+'a'})).status,400);assert.equal((await req('/towns',{...pub('bad','Bilbao'),events:[]})).status,400);
assert.equal((await req('/towns',pub('same','azpeitia.'))).status,200);assert.equal((await req('/towns',pub('short','Eibar',short))).status,200);assert.equal((await req('/towns',pub('bilbao','Bilbao'))).status,200);assert.equal((await req('/towns',pub('donosti','Donosti'))).status,200);
let board=(await req('/towns')).data;assert.equal(board.towns.length,4);assert.equal(board.towns[0].city,'Azpeitia');assert.equal(board.roundEnd,base+HOUR);assert.equal(board.minScore,MIN_SCORE);assert.equal(board.towns[3].score,short.score);
// A round begun in the old hour counts in the hour when verification accepts it.
const across=pub('across','Zarautz');now=base+HOUR;board=(await req('/towns')).data;assert.equal(board.towns.length,0);assert.equal(board.previous.roundStart,base);assert.equal(board.previous.towns.length,3);assert.equal(board.previous.towns[0].city,'Azpeitia');assert.equal((await req('/towns',publish)).status,400);assert.equal((await req('/towns',across)).status,200);assert.equal((await req('/towns')).data.towns[0].city,'Zarautz');assert.equal((await req('/towns')).data.roundEnd,base+2*HOUR);
// Restart preserves closed-hour winners and active rows.
await new Promise(r=>mod.server.close(r));delete require.cache[require.resolve('../server/server.js')];mod=require('../server/server.js');await new Promise(r=>mod.server.listen(0,'127.0.0.1',r));url='http://127.0.0.1:'+mod.server.address().port;board=(await req('/towns')).data;assert.equal(board.previous.towns[0].city,'Azpeitia');assert.equal(board.towns[0].city,'Zarautz');
// Empty later hours must not hide older winners, including across a restart.
now=base+2*HOUR+600000;board=(await req('/towns')).data;
assert.equal(board.history.find(h=>h.roundStart===base).towns[0].city,'Azpeitia');
assert.equal(board.history.find(h=>h.roundStart===base+HOUR).towns[0].city,'Zarautz');
assert.equal((await req('/health')).data.historyHours,24);
now=base+3*HOUR;board=(await req('/towns')).data;
assert.equal(board.previous.towns.length,0);
assert(board.history.some(h=>h.towns.some(t=>t.city==='Azpeitia')));
assert(board.history.every((h,i,a)=>!i||a[i-1].roundStart>h.roundStart));
now=base+25*HOUR;board=(await req('/towns')).data;
assert(!board.history.some(h=>h.towns.some(t=>t.city==='Azpeitia')));
assert(board.history.some(h=>h.towns.some(t=>t.city==='Zarautz')));
now=base+26*HOUR;board=(await req('/towns')).data;assert.equal(board.towns.length,0);const disk=fs.readFileSync(path.join(tmp,'competition.json'),'utf8');assert(!disk.includes('Azpeitia')&&!disk.includes('Zarautz'));assert.equal((await req('/towns',pub('fresh','Tolosa',short))).status,200);
console.log('PASS server: verified 100-point threshold, forged scores/traces, fixed-hour boundary, cross-hour acceptance, ties, locality dedup, idempotency, previous top 3, restart and 24h retention');
}finally{await new Promise(r=>mod.server.close(r));fs.rmSync(tmp,{recursive:true,force:true});Date.now=realNow}
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8'),scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
function browser(store={'giro-coins':'100'}){let elements={};const noop=()=>{};const el=id=>elements[id]??={classList:{add:noop,remove:noop},clientWidth:360,clientHeight:340,value:'',hidden:false,open:false,disabled:false,showModal(){assert(!this.open);this.open=true},close(){this.open=false},setAttribute:noop,addEventListener:noop,getContext(){return {}}};let failStorage=false;const sandbox={Math,Date,JSON,URL,console,setTimeout:()=>1,clearTimeout:noop,setInterval:noop,requestAnimationFrame:noop,document:{getElementById:el,addEventListener:noop},localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>{if(failStorage)throw Error('full');store[k]=v}}};sandbox.window=sandbox;let ctx=vm.createContext(sandbox);scripts.forEach(s=>vm.runInContext(s,ctx));return {ctx,store,fail(v){failStorage=v}}}
const b=browser(),ctx=b.ctx;
vm.runInContext(`
setVolume(.4);$('volumeUp').onclick();if(vol!==.5)throw Error('volume');$('mute').onclick();if(vol!==0)throw Error('mute');$('mute').onclick();if(vol!==.5)throw Error('unmute');vol=0;startLocal(123);engine.steps=2400;engine.dead=true;score=100;state='over';prepareTownOffer();if($('cityForm').hidden||finalized)throw Error('automatic optional form');finishForTown();if(!finalized||!$('publishTown').disabled)throw Error('offline form');score=99;prepareTownOffer();if(!$('cityForm').hidden)throw Error('threshold');
const n=Date.now(),testHour=Math.floor(n/3600000)*3600000,end=testHour+3600000;acceptBoard({mode:'hourly-v1',minScore:100,now:n,roundStart:testHour,roundEnd:end,towns:Array.from({length:50},(_,i)=>({city:'Pueblo '+i,score:100+i,createdAt:n,expiresAt:end})),previous:null});lastBoardSync=Date.now();renderPodium();if($('townName').textContent!=='Pueblo 49'||$('townName1').textContent!=='Pueblo 48'||$('townName2').textContent!=='Pueblo 47')throw Error('top three');score=135;state='playing';updateHourlyUI();if(!$('podiumGap').textContent.includes('13 puntos'))throw Error('accurate gap');score=148;updateHourlyUI();if($('podiumGap').textContent)throw Error('no false gap');lastBoardSync=0;score=135;updateHourlyUI();if($('podiumGap').textContent)throw Error('no offline gap');towns=[];renderPodium();if($('podium0').hidden||$('podium1').hidden||$('podium2').hidden||$('townName').textContent!=='Sin marca')throw Error('empty slots');
// Show all saved hours, skip empty hours, retain names through later empty rounds.
acceptBoard({mode:'hourly-v1',minScore:100,now:n,roundStart:testHour,roundEnd:end,towns:[],previous:null,history:[
{roundStart:testHour-HOUR,roundEnd:testHour,towns:[]},
{roundStart:testHour-2*HOUR,roundEnd:testHour-HOUR,towns:[{city:'Azpeitia',score:144}]},
{roundStart:testHour-3*HOUR,roundEnd:testHour-2*HOUR,towns:[{city:'Donosti',score:219}]},
{roundStart:testHour-27*HOUR,roundEnd:testHour-26*HOUR,towns:[{city:'Caducado',score:100}]}]});
renderPodium();let historicText=$('previousPodium').textContent;
if(!historicText.includes('Azpeitia')||!historicText.includes('Donosti')||historicText.includes('Caducado'))throw Error('24-hour historical podiums');
if(historicText.indexOf('Azpeitia')>historicText.indexOf('Donosti'))throw Error('newest hour first');
clockOffset+=HOUR;renderHourlyPodiums();if(!$('previousPodium').textContent.includes('Azpeitia'))throw Error('keep winners in later empty hour');
clockOffset+=24*HOUR;renderHourlyPodiums();if($('previousPodium').textContent.includes('Azpeitia'))throw Error('expire old podiums offline');
clockOffset=0;acceptBoard({mode:'hourly-v1',minScore:100,now:n,roundStart:testHour,roundEnd:end,towns:[],previous:{roundStart:testHour-HOUR,roundEnd:testHour,towns:[{city:'Eibar',score:200}]}});renderPodium();
if(!$('previousPodium').textContent.includes('Eibar')||!$('previousPodium').textContent.includes('Actualiza el servidor'))throw Error('old server fallback');
if(coins!==100||!useCosmetic('blue')||coins!==70)throw Error('buy cosmetic');if(!useCosmetic('blue')||coins!==70)throw Error('no double charge');if(!useCosmetic('trailViolet')||coins!==25)throw Error('buy trail');if(useCosmetic('gold')||coins!==25)throw Error('insufficient funds');if(!useCosmetic('mint')||coins!==25)throw Error('free original');if(cleanCity(' Azpeitia  ')!=='Azpeitia')throw Error('name');
`,ctx);
const b2=browser(b.store);assert.equal(vm.runInContext('coins',b2.ctx),25);assert.equal(vm.runInContext('wallet.trail',b2.ctx),'trailViolet');b.fail(true);assert.equal(vm.runInContext("useCosmetic('trailMint')",ctx),false);assert.equal(vm.runInContext('coins',ctx),25);b.fail(false);
vm.runInContext("state='playing';$('openShop').onclick();if(state!=='paused'||!$('shop').open)throw Error('shop pause');closeShop();if(state!=='paused')throw Error('explicit resume');",ctx);
console.log('PASS client: volume, optional form at 100, three empty slots, top 3 of 50, accurate and online-only gap, wallet migration, purchases/equip/reload/no double charge/storage failure, shop pauses');
const trace=makeRun(98765);vm.runInContext('startLocal(98765);',ctx);for(let t=0,i=0;t<trace.steps;t++){while(i<trace.events.length&&trace.events[i][0]===t){vm.runInContext('change()',ctx);i++}vm.runInContext('tick(1/120)',ctx)}assert.equal(vm.runInContext('score',ctx),trace.score);assert.equal(vm.runInContext('state',ctx),'over');assert.equal(vm.runInContext('engine.events.length',ctx),trace.events.length);console.log('PASS cosmetic trail and skin preserve client/server scoring, event and collision parity');
}
main().catch(e=>{console.error(e);process.exitCode=1});
