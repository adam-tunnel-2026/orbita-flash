'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto'),vm=require('node:vm');
const {Round,verify,HZ,RULES}=require('../server/game-core.js');
function makeRun(seed=123){const g=new Round(seed);while(g.seconds<40&&!g.dead){const o=g.obstacles.find(o=>o.a-g.angle>0&&o.a-g.angle<.65);if(o&&o.l===g.lane)g.switch();g.tick();}while(!g.dead&&g.seconds<120)g.tick();assert(g.dead);assert(g.score>=150);return g;}
async function main(){
const run=makeRun();assert.equal(verify(run.seed,run.events,run.steps).score,run.score);const revivedRun=makeRun(222);assert(revivedRun.revive());while(!revivedRun.dead&&revivedRun.seconds<180)revivedRun.tick();assert(revivedRun.dead);assert(verify(revivedRun.seed,revivedRun.events,revivedRun.steps).revived);assert.throws(()=>verify(run.seed,[],run.steps));assert.throws(()=>verify(run.seed,run.events,run.steps+1));assert.throws(()=>verify(run.seed,[[1,'r']],run.steps));
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'orbita-test-'));process.env.DATA_DIR=tmp;
const {normalizeCity,cityKey,server}=require('../server/server.js');assert.equal(normalizeCity('  San   Sebastián '),'San Sebastián');assert.equal(cityKey('Azpeitia.'),cityKey('azpeitia'));for(const bad of ['<script>','a','Gilípollas','A'.repeat(41),'https://evil.com'])assert.throws(()=>normalizeCity(bad));assert.equal(normalizeCity("L'Hospitalet de Llobregat"),"L'Hospitalet de Llobregat");
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const url='http://127.0.0.1:'+server.address().port;
const key=fs.readFileSync(path.join(tmp,'secret'));function token(id,seed){let b=Buffer.from(JSON.stringify({id,seed,time:Date.now()-300000,rules:RULES})).toString('base64url');return b+'.'+crypto.createHmac('sha256',key).update(b).digest('base64url')}
async function req(p,body){let r=await fetch(url+p,body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{});return {status:r.status,data:await r.json()}}
try{
assert.equal((await req('/health')).data.rules,RULES);assert.equal((await req('/rounds',{rules:RULES})).status,200);
const publish={token:token('one',run.seed),city:'Azpeitia',events:run.events,steps:run.steps,score:9999999};let result=await req('/towns',publish);assert.equal(result.status,200);assert.equal(result.data.score,run.score);const expiry=result.data.expiresAt;assert.equal((await req('/towns',publish)).data.expiresAt,expiry);assert.equal((await req('/towns')).data.towns.length,1);
assert.equal((await req('/towns',{...publish,token:publish.token+'a'})).status,400);
assert.equal((await req('/towns',{...publish,token:token('two',run.seed),events:[]})).status,400);
let second=await req('/towns',{...publish,token:token('three',run.seed),city:'azpeitia.'});assert.equal(second.status,200);assert.equal((await req('/towns')).data.towns.length,1);
// Expiry removes names and prevents a used token from extending its hour.
const realNow=Date.now;Date.now=()=>realNow()+3600001;
try{assert.equal((await req('/towns')).data.towns.length,0);assert.equal((await req('/towns',publish)).status,400);assert(!fs.readFileSync(path.join(tmp,'towns.json'),'utf8').includes('Azpeitia'));}finally{Date.now=realNow;}
console.log('PASS server: replay parity, forged score ignored, invalid trace/signature rejected, idempotent expiry, names, locality dedup');
}finally{await new Promise(r=>server.close(r));fs.rmSync(tmp,{recursive:true,force:true})}
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');const scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);let elements={},store={};const noop=()=>{};const el=id=>elements[id]??={classList:{add:noop,remove:noop},clientWidth:360,clientHeight:340,value:'',hidden:false,open:false,disabled:false,showModal(){assert(!this.open);this.open=true},close(){this.open=false},setAttribute:noop,addEventListener:noop,getContext(){return {}}};const sandbox={Math,Date,JSON,URL,console,setTimeout:()=>1,clearTimeout:noop,setInterval:noop,requestAnimationFrame:noop,document:{getElementById:el,addEventListener:noop},localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=v}};sandbox.window=sandbox;const ctx=vm.createContext(sandbox);scripts.forEach(s=>vm.runInContext(s,ctx));
vm.runInContext(`
setVolume(.4);$('volumeUp').onclick();if(vol!==.5)throw Error('volume');$('mute').onclick();if(vol!==0)throw Error('mute');$('mute').onclick();if(vol!==.5)throw Error('unmute');vol=0;startLocal(123);engine.steps=3600;engine.dead=true;score=150;state='over';prepareTownOffer();if($('finishTown').hidden)throw Error('eligible');finishForTown();if(!finalized||$('cityForm').hidden||!$('publishTown').disabled)throw Error('offline form');score=149;prepareTownOffer();if(!$('finishTown').hidden)throw Error('threshold');
towns=Array.from({length:50},(_,i)=>({city:'Pueblo '+i,score:150+i,expiresAt:Date.now()+3600000}));townIndex=-1;let seen=new Set();for(let i=0;i<50;i++){rotateTown();seen.add($('townName').textContent)}if(seen.size!==50)throw Error('50 rotation');towns[0].expiresAt=Date.now()-1;rotateTown();if(towns.length!==49)throw Error('individual expiry');
if(cleanCity(' Azpeitia  ')!=='Azpeitia')throw Error('name');
`,ctx);
console.log('PASS client: volume, threshold 150, finalization, honest offline state, 50-name rotation, individual expiry');
// Simulate the browser wrapper with the same fixed ticks used by server verification.
const trace=makeRun(98765);vm.runInContext(`startLocal(98765);`,ctx);for(let t=0,i=0;t<trace.steps;t++){while(i<trace.events.length&&trace.events[i][0]===t){vm.runInContext('change()',ctx);i++;}vm.runInContext('tick(1/120)',ctx);}assert.equal(vm.runInContext('score',ctx),trace.score);assert.equal(vm.runInContext('state',ctx),'over');console.log('PASS browser/server score and collision parity');
}
main().catch(e=>{console.error(e);process.exitCode=1});
