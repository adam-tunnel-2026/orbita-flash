'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.join(__dirname,'..'),html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const catalog=JSON.parse(fs.readFileSync(path.join(root,'i18n/catalog.json'),'utf8'));
const languages=['es','eu','en','fr'];
const version=/versionName '([^']+)'/.exec(fs.readFileSync(path.join(root,'app/build.gradle'),'utf8'))[1];
for(const [source,row] of Object.entries(catalog)) {
 assert.deepEqual(Object.keys(row).sort(),[...languages].sort(),source);
 for(const language of languages) {
  assert(row[language].trim(),source+' '+language);
  assert.deepEqual([...row[language].matchAll(/\{(\w+)\}/g)].map(m=>m[1]).sort(),[...source.matchAll(/\{(\w+)\}/g)].map(m=>m[1]).sort(),source+' placeholders '+language);
 }
}
function browser(preferences,store={},nativeLanguage) {
 const elements={};const noop=()=>{};
 const el=id=>elements[id]??={style:{},dataset:{},replaceChildren:noop,append:noop,contains:()=>false,classList:{add:noop,remove:noop},clientWidth:360,clientHeight:340,value:'',hidden:false,open:false,disabled:false,attributes:{},
  showModal(){this.open=true},close(){this.open=false},setAttribute(k,v){this.attributes[k]=v},addEventListener:noop,getContext(){return {}}};
 const decode=s=>s.replace(/&quot;/g,'"').replace(/&#x27;/g,"'").replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>');
 const staticNodes=[...html.matchAll(/<span data-i18n="([^"]*)">/g)].map(m=>({key:decode(m[1]),textContent:'',getAttribute(){return this.key}}));
 const document={documentElement:{},getElementById:el,createElement:()=>el('generated-'+Object.keys(elements).length),createElementNS:()=>el('generated-'+Object.keys(elements).length),addEventListener:noop,querySelectorAll:selector=>selector==='[data-i18n]'?staticNodes:[]};
 const context={Math,Date,JSON,URL,console,setTimeout:()=>1,clearTimeout:noop,setInterval:noop,requestAnimationFrame:noop,document,navigator:{languages:preferences},
  localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>{store[k]=String(v)}}};
 context.window=context;
 if(nativeLanguage)context.ORBITA_LANG=nativeLanguage;
 const ctx=vm.createContext(context);scripts.forEach(s=>vm.runInContext(s,ctx));
 return {ctx,document,staticNodes,store};
}
const initial={'giro-coins':'100','giro-best':'200','orbita-city':'Azpeitia','giro-runs':'[]'};
for(const language of languages) {
 const b=browser([language+'-ES'],{...initial});
 assert.equal(vm.runInContext('LANGUAGE',b.ctx),language);
 assert.equal(b.document.documentElement.lang,language);
 for(const node of b.staticNodes)assert.equal(node.textContent,catalog[node.key][language].replace('{version}',version));
 assert.equal(vm.runInContext('coins',b.ctx),100);assert.equal(vm.runInContext('best',b.ctx),200);
 assert.equal(b.store['orbita-city'],'Azpeitia');
 vm.runInContext("startLocal(123);earned=3;score=150;results();renderShop();",b.ctx);
 assert.equal(vm.runInContext("$('earnings').textContent",b.ctx),catalog['Has recogido {n} monedas.'][language].replace('{n}','3'));
 assert.equal(vm.runInContext("$('reason').textContent",b.ctx),catalog['Has tocado un bloque rosa. Cambia de carril antes de llegar.'][language]);
 assert.equal(vm.runInContext("$('buyBlue').textContent",b.ctx),catalog['Comprar'][language]);
 assert.equal(vm.runInContext("useCosmetic('blue')",b.ctx),true);
 const again=browser([language],b.store);assert.equal(vm.runInContext('coins',again.ctx),70);assert.equal(vm.runInContext('wallet.skin',again.ctx),'blue');
 assert.equal(vm.runInContext("tr('¡Marca aceptada para {city}: {score} puntos! Compite hasta las {time}. Solo los tres mejores pueblos aparecen en el podio.',{city:'Azpeitia',score:150,time:'12:00'})",b.ctx).includes('Azpeitia'),true);
}
for(const [prefs,expected] of [[['es-MX'],'es'],[['eu-ES'],'eu'],[['en-US'],'en'],[['fr-FR'],'fr'],[['de-DE'],'es'],[['ar-MA'],'es'],[['de-DE','fr-FR'],'fr'],[[],'es']])assert.equal(vm.runInContext('LANGUAGE',browser(prefs).ctx),expected);
assert.equal(vm.runInContext('LANGUAGE',browser(['en-US'],{},'eu').ctx),'eu');
// Changing the phone language must not write or reset any game data.
const saved=browser(['es'],{...initial});vm.runInContext("useCosmetic('blue')",saved.ctx);
const before=JSON.stringify(saved.store);const switched=browser(['eu-ES'],saved.store);
assert.equal(JSON.stringify(switched.store),before);assert.equal(vm.runInContext('wallet.skin',switched.ctx),'blue');
const xml=fs.readFileSync(path.join(root,'app/src/main/res/xml/locales_config.xml'),'utf8');
assert.deepEqual([...xml.matchAll(/android:name="([^"]+)"/g)].map(m=>m[1]),languages);
for(const folder of ['values','values-en','values-eu','values-fr'])assert.equal((fs.readFileSync(path.join(root,'app/src/main/res',folder,'strings.xml'),'utf8').match(/<string /g)||[]).length,Object.keys(catalog).length);
console.log('PASS i18n: '+Object.keys(catalog).length+' messages × 4 languages, placeholders, automatic regional matching, native language override, Spanish fallback, static and live text, purchases/reload, preserved data and unchanged town names; Arabic not included');
