"""Android platform permission contracts for background jobs (no device required)."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
android = "{http://schemas.android.com/apk/res/android}"
manifest = ET.parse(root / "app/src/main/AndroidManifest.xml").getroot()
permissions = {item.attrib[android + "name"] for item in manifest.findall("uses-permission")}
java = "\n".join(p.read_text() for p in (root / "app/src/main/java").rglob("*.java"))
if re.search(r"\.setRequiredNetwork(?:Type)?\s*\(", java):
    for permission in ("INTERNET", "ACCESS_NETWORK_STATE"):
        assert "android.permission." + permission in permissions, f"Network JobScheduler requires {permission} (Android 14+)"
if re.search(r"\.setPersisted\s*\(\s*true\s*\)", java):
    assert "android.permission.RECEIVE_BOOT_COMPLETED" in permissions, "Persisted JobScheduler requires RECEIVE_BOOT_COMPLETED"
for service in manifest.findall("application/service"):
    if service.attrib.get(android + "name") == ".UpdateJobService":
        assert service.attrib.get(android + "permission") == "android.permission.BIND_JOB_SERVICE"
        break
else:
    raise AssertionError("UpdateJobService is not registered")
print("PASS Android platform contracts: network permissions, persisted jobs and protected job service")
