'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{EventEmitter}=require('node:events');
async function regression(){
 const source=fs.readFileSync(path.join(__dirname,'../server/server.js'),'utf8');
 const code=source.slice(source.indexOf('function replay(input)'),source.indexOf('function body(req)'));
 const threads=[],timers=new Map();let nextTimer=0,failConstruction=false;
 class Worker extends EventEmitter{
  constructor(){super();if(failConstruction)throw Error('thread creation failed');threads.push(this)}
  terminate(){this.emit('exit',1);return Promise.resolve(1)}
 }
 const context=vm.createContext({Worker,Promise,Error,path,__dirname:path.join(__dirname,'../server'),setTimeout(fn){const id=++nextTimer;timers.set(id,fn);return id},clearTimeout(id){timers.delete(id)}});
 vm.runInContext('let workers=0;'+code,context);
 const replay=()=>vm.runInContext('replay({})',context),count=()=>vm.runInContext('workers',context);
 const a=replay(),b=replay();let answered=false;a.then(()=>{answered=true});
 threads[0].emit('message',{score:200});threads[1].emit('message',{score:150});
 await Promise.resolve();assert(!answered,'a result must wait for thread exit');assert.equal(count(),2);
 await assert.rejects(replay(),e=>e.status===503,'real concurrency limit remains enforced');
 threads[0].emit('exit',0);assert.equal((await a).score,200);assert.equal(count(),1);
 // The very next request can be accepted without waiting or retrying.
 const c=replay();assert.equal(count(),2);threads[2].emit('message',{score:120});threads[2].emit('exit',0);assert.equal((await c).score,120);
 threads[1].emit('exit',0);await b;assert.equal(count(),0);assert.equal(timers.size,0);
 // Rejected traces, thread errors and timeouts must also release the slot.
 const invalid=replay(),invalidCheck=assert.rejects(invalid,/invalid trace/);threads[3].emit('message',{error:'invalid trace'});threads[3].emit('exit',0);await invalidCheck;assert.equal(count(),0);
 const crashed=replay(),crashCheck=assert.rejects(crashed,/thread crash/);threads[4].emit('error',Error('thread crash'));threads[4].emit('exit',1);await crashCheck;assert.equal(count(),0);
 const timed=replay(),timeCheck=assert.rejects(timed,/tardó demasiado/);[...timers.values()][0]();await timeCheck;assert.equal(count(),0);assert.equal(timers.size,0);
 failConstruction=true;await assert.rejects(replay(),/thread creation failed/);assert.equal(count(),0,'constructor failure must not leak capacity');
 console.log('PASS verification workers: message-before-exit regression, immediate sequential acceptance, genuine capacity limit, invalid trace, crash, timeout and construction-failure cleanup');
}
module.exports=regression;
if(require.main===module)regression().catch(e=>{console.error(e);process.exitCode=1});
