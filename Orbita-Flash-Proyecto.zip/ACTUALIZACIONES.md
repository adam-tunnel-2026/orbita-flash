# Órbita Flash 0.7.1 — corrección del inicio y actualizaciones por APK


## Corrección 0.7.1

Se añade ACCESS_NETWORK_STATE, obligatorio para programar trabajos con red en
Android 14+ cuando la app apunta a API 34 o superior. La versión 0.7.0 lo omitía
y programaba la comprobación en onCreate, provocando SecurityException en esos
sistemas. No hay un registro del móvil del usuario para confirmar que sea la
única causa de su cierre. La programación en segundo plano y la inicialización
del actualizador ahora toleran fallos para permitir abrir el juego.

La prueba de configuración detecta el permiso ausente en el ZIP 0.7.0 y pasa en
0.7.1. Se ejecutan también las pruebas existentes y se analiza la sintaxis Java.
No se ha compilado la APK ni probado el arranque en un dispositivo Android.

Estado: código preparado y reglas comprobadas localmente. APK todavía sin compilar,
sin publicar y sin prueba de instalación en Android. No se ha accedido al repositorio
ni modificado el servidor remoto.

## Qué hace

- Botón superior «Actualizaciones», que pasa a «① Actualizar · versión» cuando hay
  una versión nueva compatible. Se comprueba al abrir/reanudar, con un intervalo
  mínimo de cinco minutos durante esa ejecución.
- Botón «Activar avisos» para solicitar permiso de notificaciones. El sistema
  programa comprobaciones aproximadamente cada seis horas cuando hay red; Android
  puede retrasarlas por batería, inactividad o restricciones. No es un aviso
  instantáneo. Una app detenida forzosamente no puede garantizar avisos.
- Notificación «① Nueva actualización disponible». El contador del icono depende
  del lanzador y los permisos del teléfono.
- Diálogo nativo con barra verde de 28 dp, porcentaje y MB realmente descargados.
  Si no se conoce el tamaño, muestra MB y progreso indeterminado, nunca un porcentaje
  inventado. Al comprobar el archivo se indica «Comprobando».
- Descarga con DownloadManager: continúa al cerrar la pantalla y se recupera
  al volver. Respeta las restricciones del teléfono y no descarga en roaming.
- Al completar y verificar una descarga con el diálogo visible, abre el instalador
  de Android una sola vez. Si el usuario cancela, puede pulsar «Instalar actualización».
  Si se terminó con la app cerrada, se instala al volver y pulsar el botón.
- Android pide autorización para instalar desde esta fuente y confirmación de
  instalación. No se instala silenciosamente.
- Comprueba SHA-256, tamaño, versión, compatibilidad Android, identificador y firma.
  Rechaza una APK de otra app, dañada, antigua o firmada con otra clave.

## Datos y firma: condición necesaria antes de distribuir

Se mantienen `es.orbitaflash.game`, la base de WebView
`https://orbita-flash.invalid/` y todas las claves de almacenamiento del juego.
No se borran datos, cachés, monedero, historial, aspectos ni localidad. El archivo
del juego y el código del servidor siguen idénticos a 0.6.0.

La versión anterior se compilaba como DEBUG en un runner temporal de GitHub. Eso
NO garantiza que se conserve su clave entre compilaciones. Para instalar esta
versión encima sin perder datos hay que disponer de la clave que firmó la APK
que ya está instalada. Una clave nueva no sustituye a la original.

NO DESINSTALAR para resolver un fallo de firma: se perderían los datos locales.
No se ha verificado la firma de la APK actualmente instalada ni se dispone aquí
de su clave. La publicación no está lista hasta resolver esto y completar la prueba
de actualización en un dispositivo.

## Preparar la compilación

Repositorio previsto: `adam-tunnel-2026/orbita-flash`.

1. Sustituir `Orbita-Flash-Proyecto.zip` de la raíz por el proyecto nuevo.
2. Sustituir el workflow existente `.github/workflows/orbita-flash.yml` por el
   incluido en este proyecto. Mantener un único workflow de Órbita Flash.
   Subir solamente el ZIP NO sustituye el workflow externo.
3. Un push o ejecución manual con `publish=false` genera la APK de PRUEBA.
   No la distribuye como actualización ni publica un aviso.
4. Para publicar hay que añadir a GitHub Actions los secretos de la firma original:
   `ORBITA_KEYSTORE_BASE64`, `ORBITA_STORE_PASSWORD`, `ORBITA_KEY_ALIAS`,
   `ORBITA_KEY_PASSWORD` y `ORBITA_CERT_SHA256`.
   La huella SHA-256 debe contrastarse con la APK ya instalada usando apksigner,
   no elegirse simplemente a partir de una clave recién creada. No pegar claves
   ni contraseñas en un chat ni añadirlas al ZIP/repositorio.
5. Ejecutar manualmente con `publish=true`. Si faltan la clave o su huella,
   se detiene. El repositorio debe permitir crear Releases con `GITHUB_TOKEN`.

El workflow compila, comprueba la firma fijada y genera `update.json` a partir de
los bytes y versión reales de la APK. Crea una Release borrador con los dos archivos
y la publica completa. No reemplaza una versión existente: para publicar otra hay
que aumentar `versionCode` y `versionName` en `app/build.gradle`.

Los avisos consultan:
`https://github.com/adam-tunnel-2026/orbita-flash/releases/latest/download/update.json`

Esta ruta y sus archivos deben ser PÚBLICOS y accesibles sin credenciales.
No se incluyen tokens de GitHub en la APK. Un repositorio privado necesitaría
otra ruta pública gestionada para la distribución.

El actualizador aparece por primera vez en 0.7.0: los usuarios de 0.6.0 tendrán que
recibir e instalar esta primera APK por el canal actual, con firma compatible.
Después podrán recibir avisos de 0.8.0 y posteriores desde el juego.

## Pruebas realizadas aquí

- Pruebas existentes de servidor, podio horario, monedero, aspectos y paridad
  cliente/servidor: correctas.
- 24 comprobaciones JVM de versiones, HTTPS, repositorio permitido, límites de
  tamaño, integridad del archivo y descargas truncadas: correctas.
- Generador de metadatos: usa tamaño/hash reales y rechaza versiones y apps
  incorrectas. Entrada de aapt simulada en la prueba, sin APK fabricada.
- Sintaxis de los siete archivos Java (sin comprobar tipos Android), YAML, bloques
  shell del workflow y XML del manifiesto: correctos.
- Verificación por bytes de que el juego y los módulos del servidor no cambian.

Falta: compilación Android completa, revisión visual en móvil y prueba real
0.7.0 → versión siguiente con la misma firma. Este entorno no dispone del SDK
Android ni Gradle. Chromium está instalado pero no consigue arrancar en el entorno.
No confundir las pruebas JVM con una compilación de la APK.

## Prueba de aceptación antes de publicar

1. Con una APK firmada con la misma clave que la versión de prueba siguiente,
   conseguir monedas, comprar un aspecto, guardar un récord y seleccionar pueblo.
2. Publicar en un canal de prueba una versión con código superior. Comprobar aviso,
   permiso de notificaciones, barra, porcentaje y progreso con red lenta.
3. Cerrar y volver al juego durante la descarga. Probar sin conexión y sin espacio.
4. Cancelar el instalador: no debe abrirse en bucle; permitir reintentar manualmente.
5. Completar la instalación SIN desinstalar. Abrir y comprobar todos los datos.
6. Verificar rechazo de una APK con firma distinta sin que afecte a los datos actuales.

## Distribución futura en Google Play

Esta implementación es para APK distribuida directamente. Antes de publicar el
juego en Google Play hay que sustituir el instalador propio y su permiso
`REQUEST_INSTALL_PACKAGES` por el sistema de actualizaciones de Google Play.
No usar esta variante tal cual para una publicación en Play Store.

No se ha modificado Adam Tunnel, Encajoy, DNS, Cloudflare, Nginx ni el servicio
remoto de la competición.
