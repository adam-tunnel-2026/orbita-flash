# Órbita Flash 0.9.4 — corrección del aspecto del anillo

Corrección de las diferencias observadas en la captura de la APK 0.9.3:
- Panel compacto: cabecera sin banda de fondo y tarjetas de 52 px de alto.
- Centro de 48 % del ancho, laterales estrechos con mayor inclinación.
- Superficies opacas y texto oculto en caras traseras: sin nombres fantasma.
- Solo la tarjeta central muestra puntos y hora; la fecha sigue en la lista.
- Cuatro segundos de lectura en el centro y giro suave de 1,2 segundos.
- Pausar o navegar centra inmediatamente la tarjeta elegida.
- Flecha curva y texto pequeño de pausa, sin los botones grandes de la 0.9.3.
- Lista completa disponible desde el icono ☷; se conserva todo el Top 3 de 24 h.

Se conserva la firma permanente existente y el actualizador. Código Android 17.
Pruebas de lógica del anillo, competición, idiomas y contratos Android aprobadas.
La vista previa HTML usa el mismo código del carrusel y datos de ejemplo separados.
No se ha compilado una APK ni validado visualmente en Android en esta sesión.

---

# Órbita Flash 0.9.3 — anillo giratorio de pueblos

El histórico bajo «Bolas y estelas · Tienda» presenta un anillo horizontal con
los pueblos de las últimas 24 horas. Cada etiqueta muestra su medalla, localidad,
puntos, franja horaria y fecha. Se incluyen los tres primeros de cada hora, sin
mezclar el histórico dorado con el podio verde de la hora actual.

El giro es automático y suave. Se puede pausar tocando el anillo o el botón,
navegar con flechas o deslizando a los lados, y consultar la lista completa.
El desplazamiento vertical sigue funcionando. Solo hay hasta siete etiquetas
en pantalla, aunque existan 72 resultados. Se respeta la preferencia de reducir
movimiento. El giro se detiene fuera de pantalla, al plegar el panel o al ocultar
la aplicación. No hay marcas de ejemplo integradas: usa los resultados reales.

Versión Android: 0.9.3, código 16. Se conserva el certificado público y la
configuración de firma permanente, sin generar otra clave. No requiere otro
cambio del servidor si ya tiene el histórico de 24 horas de la versión 0.9.2.
Se mantienen los idiomas automáticos y los datos de juego existentes.

Verificación de esta entrega:
- Pruebas de anillo, pausa, navegación, 72 puestos, caducidad y movimiento reducido.
- Pruebas de competición, cliente, idiomas y contratos Android aprobadas.
- No se ha compilado ni firmado una APK en esta sesión.
- No se ha podido verificar visualmente en Chromium: el entorno bloquea su socket.
- El proyecto debe compilarse con el secreto ORBITA_SIGNING_BUNDLE existente.

Para ejecutar las pruebas del anillo por separado:
node tests/podium-carousel.test.cjs

---

# Órbita Flash 0.9.2 — podios visibles durante 24 horas

El panel inferior ahora muestra todos los podios guardados de las últimas 24 horas,
agrupados por hora y fecha, con los más recientes primero. Solo omite horas sin
publicaciones: una hora vacía nunca oculta los pueblos de horas anteriores.
Cada Top 3 permanece hasta 24 horas desde el cierre de su ronda, también cuando
se vuelve a abrir la app con conexión. No se modifica la competición de la hora actual.
Se mantienen la firma permanente y el actualizador de la 0.9.1.

Requiere APK 0.9.2 (código 15) y actualización del servidor: /towns incluye history,
y /health anuncia historyHours:24. La API conserva previous para APK anteriores.
No se modifica el formato de competition.json ni se borran sus podios existentes.
Si el servidor es anterior, se muestra lo disponible de previous y se indica que
hay que actualizar el servidor; no se presenta como un historial completo vacío.
No se pueden recuperar resultados que ya hayan caducado o se hayan borrado antes.

Validación: pruebas HTTP de horas vacías, orden, límite exacto de 24 horas y reinicio;
pruebas del panel, fallback antiguo y caducidad sin conexión; idiomas y permisos.
No se ha compilado ni instalado esta APK ni actualizado el servidor remoto aquí.

# Órbita Flash 0.9.1 — descargar e instalar una sola APK

## Cambio de esta actualización

- Tocar el aviso o «Actualizar» con una versión disponible abre el progreso e inicia
  la descarga dentro del juego. No abre el navegador ni descarga un ZIP.
- La notificación incluye la acción «Descargar actualización».
- Buscar versiones sin una actualización conocida no inicia descargas sin otra
  acción del usuario. Las comprobaciones en segundo plano tampoco descargan APKs.
- Se conserva una única descarga pendiente; volver a tocar no crea otra descarga.
- Se muestran porcentaje y MB reales; si se desconoce el tamaño, progreso indeterminado.
- Después se verifica la APK y Android solicita confirmar la instalación.
- Los permisos de avisos y de instalar desde esta app dependen de Android.
- Las comprobaciones en segundo plano siguen siendo periódicas, aproximadamente
  cada seis horas; no son notificaciones push ni se garantiza entrega inmediata.
- Se mantiene ORBITA_SIGNING_BUNDLE y la misma huella permanente. No se crea clave.
- Código 14, versión 0.9.1. Compatible por firma con la nueva serie permanente;
  incompatible con la antigua 0.8.1 de prueba que usa otro certificado.

El artefacto de Actions contiene solamente Orbita-Flash.apk. Los archivos update.json
 y firma-publica.sha256 se publican como metadatos separados en Releases, para uso
 del actualizador; el usuario no necesita descargarlos ni extraerlos.

Estado: cambios preparados y pruebas locales ejecutadas. Falta compilar Android,
probar en un dispositivo y publicar la versión en GitHub.

# Órbita Flash 0.9.0 — idiomas y actualizaciones por APK


## Firma permanente en 0.9.0

FIRMA-PERMANENTE.md sustituye las instrucciones anteriores de firma y workflow.
Se utiliza un único secreto ORBITA_SIGNING_BUNDLE y una identidad nueva fija.
No permite actualizar las APK antiguas firmadas con otras claves.
Las instrucciones de versiones anteriores que siguen se conservan como referencia
y no deben usarse para configurar los secretos de la versión nueva.

## Nuevo en 0.8.1

Se destaca el podio de la hora anterior con fondo azul-violeta, borde y título
dorados, icono de trofeo y texto claro. Aparece desplegado inicialmente y puede
plegarse. No cambia la duración ni el cálculo de las rondas. La marca compite
hasta el final de la hora de aceptación y puede salir del Top 3 antes si la superan.
El apartado inferior muestra únicamente la hora inmediatamente anterior; conservar
resultados hasta 24 horas en el servidor no significa que todos aparezcan aquí.
Se mantienen los idiomas y los elementos de pruebas/publicidad, según lo acordado.
Las pruebas existentes del podio y de idiomas pasan. Falta compilar y revisar
la presentación de esta versión en Android.

## Nuevo en 0.8.0

Idiomas automáticos: español, euskera, inglés y francés; español por defecto.
Sin árabe. Se traducen juego y actualizador. Lee IDIOMAS.md.
El usuario confirmó que la APK 0.7.1 abre correctamente en su móvil. La nueva
0.8.0 todavía no se ha compilado ni probado en un dispositivo.

## Corrección 0.7.1

Se añade ACCESS_NETWORK_STATE, obligatorio para programar trabajos con red en
Android 14+ cuando la app apunta a API 34 o superior. La versión 0.7.0 lo omitía
y programaba la comprobación en onCreate, provocando SecurityException en esos
sistemas. No hay un registro del móvil del usuario para confirmar que sea la
única causa de su cierre. La programación en segundo plano y la inicialización
del actualizador ahora toleran fallos para permitir abrir el juego.

La prueba de configuración detecta el permiso ausente en el ZIP 0.7.0 y pasa en
0.7.1. Se ejecutan también las pruebas existentes y se analiza la sintaxis Java.
No se ha compilado la APK ni probado el arranque en un dispositivo Android.

Estado: código preparado y reglas comprobadas localmente. APK todavía sin compilar,
sin publicar y sin prueba de instalación en Android. No se ha accedido al repositorio
ni modificado el servidor remoto.

## Qué hace

- Botón superior «Actualizaciones», que pasa a «① Actualizar · versión» cuando hay
  una versión nueva compatible. Se comprueba al abrir/reanudar, con un intervalo
  mínimo de cinco minutos durante esa ejecución.
- Botón «Activar avisos» para solicitar permiso de notificaciones. El sistema
  programa comprobaciones aproximadamente cada seis horas cuando hay red; Android
  puede retrasarlas por batería, inactividad o restricciones. No es un aviso
  instantáneo. Una app detenida forzosamente no puede garantizar avisos.
- Notificación «① Nueva actualización disponible». El contador del icono depende
  del lanzador y los permisos del teléfono.
- Diálogo nativo con barra verde de 28 dp, porcentaje y MB realmente descargados.
  Si no se conoce el tamaño, muestra MB y progreso indeterminado, nunca un porcentaje
  inventado. Al comprobar el archivo se indica «Comprobando».
- Descarga con DownloadManager: continúa al cerrar la pantalla y se recupera
  al volver. Respeta las restricciones del teléfono y no descarga en roaming.
- Al completar y verificar una descarga con el diálogo visible, abre el instalador
  de Android una sola vez. Si el usuario cancela, puede pulsar «Instalar actualización».
  Si se terminó con la app cerrada, se instala al volver y pulsar el botón.
- Android pide autorización para instalar desde esta fuente y confirmación de
  instalación. No se instala silenciosamente.
- Comprueba SHA-256, tamaño, versión, compatibilidad Android, identificador y firma.
  Rechaza una APK de otra app, dañada, antigua o firmada con otra clave.

## Datos y firma: condición necesaria antes de distribuir

Se mantienen `es.orbitaflash.game`, la base de WebView
`https://orbita-flash.invalid/` y todas las claves de almacenamiento del juego.
No se borran datos, cachés, monedero, historial, aspectos ni localidad. Las reglas
deterministas y el código del servidor no cambian; la interfaz se traduce en 0.8.0.

La versión anterior se compilaba como DEBUG en un runner temporal de GitHub. Eso
NO garantiza que se conserve su clave entre compilaciones. Para instalar esta
versión encima sin perder datos hay que disponer de la clave que firmó la APK
que ya está instalada. Una clave nueva no sustituye a la original.

NO DESINSTALAR para resolver un fallo de firma: se perderían los datos locales.
No se ha verificado la firma de la APK actualmente instalada ni se dispone aquí
de su clave. La publicación no está lista hasta resolver esto y completar la prueba
de actualización en un dispositivo.

## Preparar la compilación actual (0.9.1, código 14)

1. Sustituir `Orbita-Flash-Proyecto.zip` en la raíz de `adam-tunnel-2026/orbita-flash`.
   No subir el ZIP que contiene la APK ni descomprimir el proyecto en esa raíz.
2. Sustituir `.github/workflows/orbita-flash.yml` por el workflow entregado.
   Mantener únicamente ese workflow de Órbita Flash.
3. Conservar el secreto existente `ORBITA_SIGNING_BUNDLE`. No crear otra clave.
   No hacen falta los cinco secretos del procedimiento antiguo.
4. Un push genera `Orbita-Flash-APK-FIRMADA`. El ZIP de ese artefacto contiene
   solamente `Orbita-Flash.apk`, compilada como RELEASE.
5. Para comprobar actualizaciones: Actions → Run workflow, `verify_update=true`
   y `publish=false`. Para publicar después: `verify_update=true` y `publish=true`.
   La publicación se detiene si fallan las pruebas, si la firma no coincide o
   si la versión ya está publicada.

El proyecto y la identidad están preparados, pero esta revisión no ha compilado,
instalado ni publicado una APK. La 0.8.1 anterior usa otra firma y no puede
actualizarse encima con esta identidad. No desinstalarla si contiene datos importantes.
Las siguientes versiones de la serie permanente deben conservar esta clave e
incrementar versionCode y versionName.

Los avisos consultan:
`https://github.com/adam-tunnel-2026/orbita-flash/releases/latest/download/update.json`

Esta ruta y sus archivos deben ser PÚBLICOS y accesibles sin credenciales.
No se incluyen tokens de GitHub en la APK. Un repositorio privado necesitaría
otra ruta pública gestionada para la distribución.

El actualizador aparece por primera vez en 0.7.0: los usuarios de 0.6.0 tendrán que
recibir e instalar esta primera APK por el canal actual, con firma compatible.
Después podrán recibir avisos de 0.8.0 y posteriores desde el juego.

## Pruebas realizadas aquí

- Pruebas existentes de servidor, podio horario, monedero, aspectos y paridad
  cliente/servidor: correctas.
- 24 comprobaciones JVM de versiones, HTTPS, repositorio permitido, límites de
  tamaño, integridad del archivo y descargas truncadas: correctas.
- Generador de metadatos: usa tamaño/hash reales y rechaza versiones y apps
  incorrectas. Entrada de aapt simulada en la prueba, sin APK fabricada.
- Sintaxis de los siete archivos Java (sin comprobar tipos Android), YAML, bloques
  shell del workflow y XML del manifiesto: correctos.
- Verificación por bytes de que el motor determinista y los módulos del servidor no cambian.
- Pruebas de idiomas y conservación de datos descritas en IDIOMAS.md.

Falta: compilación Android completa, revisión visual en móvil y prueba real
0.7.0 → versión siguiente con la misma firma. Este entorno no dispone del SDK
Android ni Gradle. Chromium está instalado pero no consigue arrancar en el entorno.
No confundir las pruebas JVM con una compilación de la APK.

## Prueba de aceptación antes de publicar

1. Con una APK firmada con la misma clave que la versión de prueba siguiente,
   conseguir monedas, comprar un aspecto, guardar un récord y seleccionar pueblo.
2. Publicar en un canal de prueba una versión con código superior. Comprobar aviso,
   permiso de notificaciones, barra, porcentaje y progreso con red lenta.
3. Cerrar y volver al juego durante la descarga. Probar sin conexión y sin espacio.
4. Cancelar el instalador: no debe abrirse en bucle; permitir reintentar manualmente.
5. Completar la instalación SIN desinstalar. Abrir y comprobar todos los datos.
6. Verificar rechazo de una APK con firma distinta sin que afecte a los datos actuales.

## Distribución futura en Google Play

Esta implementación es para APK distribuida directamente. Antes de publicar el
juego en Google Play hay que sustituir el instalador propio y su permiso
`REQUEST_INSTALL_PACKAGES` por el sistema de actualizaciones de Google Play.
No usar esta variante tal cual para una publicación en Play Store.

No se ha modificado Adam Tunnel, Encajoy, DNS, Cloudflare, Nginx ni el servicio
remoto de la competición.
