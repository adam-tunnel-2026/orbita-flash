# Órbita Flash 0.9.0 — idiomas automáticos

Idiomas incluidos: español (es), euskera (eu), inglés (en) y francés (fr).
No se incluye árabe. La primera versión está pensada principalmente para España.

La app usa el primer idioma compatible de la lista de preferencias del teléfono.
Por ejemplo, eu-ES usa euskera, es-MX español, en-US inglés y fr-FR francés.
Si ninguno está incluido, usa español. No detecta el idioma por GPS, pueblo o SIM.
Android 13+ puede ofrecer también estos idiomas en el ajuste de idioma de la app.
Ese ajuste, si el usuario lo cambia, tiene prioridad sobre el idioma general.

La interfaz web recibe el idioma de la configuración Android; la vista web suelta
puede obtenerlo del navegador. Al cambiar el idioma del teléfono y abrir de nuevo
la app, se adapta la interfaz. No se guarda un idioma que anule futuras preferencias.

Se traducen menús, instrucciones, resultados, tienda de cosméticos, controles,
accesibilidad, calendario horario del podio y mensajes de publicación. Los mensajes
conocidos del servidor se traducen en el cliente, sin modificar el servidor.
También se traducen el aviso, la descarga, los permisos explicativos de instalación,
los errores del actualizador y la confirmación de salida. Los diálogos del sistema
Android tienen sus propios textos y dependen de la configuración del sistema.

Los nombres escritos por los jugadores no se traducen. No se cambian las claves de
almacenamiento, el identificador de la app, la base de WebView ni las reglas de juego.
Cambiar de idioma no reinicia monedas, compras, récords ni pueblo.

El catálogo i18n/catalog.tsv contiene 185 mensajes con sus cuatro versiones.
`python3 tools/generate-translations.py` regenera el JSON, los recursos Android,
el acceso nativo y el catálogo incluido en la página. Nuevos textos de interfaz
requieren también utilizar `tr(...)` o `L10n.text(...)` donde corresponda.

Pruebas completadas: cuatro idiomas, variantes regionales, prioridad del idioma
nativo frente al navegador, español por defecto, plantillas con variables,
textos estáticos y dinámicos, compras y recarga, conservación de datos al cambiar
idioma, recursos Android completos, generación repetible, reglas deterministas
sin cambios, pruebas de competición/monedero, permisos del trabajo en segundo
plano, XML y sintaxis Java y del workflow.

Pendiente: compilación Android completa y revisión visual en el móvil. No se ha
publicado ninguna APK ni aviso remoto. Las traducciones necesitan revisión de
uso en dispositivo; las pruebas automáticas no certifican la calidad lingüística.

La versión sube a versionCode 13 / versionName 0.9.0. Debe instalarse encima de la
anterior con la misma firma; no desinstalar. La firma estable y la publicación de
Releases siguen siendo necesarias para que lleguen futuras actualizaciones.
Subir el ZIP de código no publica una APK ni activa por sí mismo el aviso.
